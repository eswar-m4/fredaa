#---------------------------------------------------------------------------------------#
# Name				      ::	Vikram Joghee									        # 
# Bot_Name			      ::	WCM HTML Text Comparison – With Change Details			#
# Developed_Date	      ::	20.08.2024	                                            #
# Initial_Version	      ::	1.0	                                                    #
# Updated_Date	          ::	04.10.2024	                                            #
# Updated_Version		  ::    1.2                                                     #
# Updated_Date	          ::	23.10.2024	                                            #
# Updated_Version		  ::    1.3                                                     #
# Updated_M3_Date         ::    27.01.2025     							                #
# Updated_M3_Version	  ::    1.2  (UAT env by Gowri)                                 #
# # Updated_M3_Date       ::    15.02.2025     							                #
# Updated_M3_Version	  ::    1.3  (Included Input Validation by Gowri)               #	
# Updated_M3_Date         ::    25.03.2025     							                #
# Updated_M3_Version	  ::    1.6  (Updated botbase & removed send_msg_initiated      #
#                                                           in main func) by Gowri      #								
#---------------------------------------------------------------------------------------#

# Update :  added url parsing and changes in url construction for added_links(new html page)
# version : 1.7 by Gowri on 21.04.2025

# Update :  Fixed counts , added function to cleanse text(soft hyphens), url comparison along with their domains,
# version : 1.8 by Gowri on 29.04.2025

# Update  :  Cleansed html content at the initial stage
# version : 1.9 by Gowri on 30.04.2025

################# standard modules ###############

import boto3
import html
import re
import os
import sys
import datetime
import botocore
import unicodedata
import time
import json
from datetime import datetime
import difflib
import random
import threading
from difflib import unified_diff
from botocore.exceptions import ClientError
from bs4 import BeautifulSoup
from urllib.parse import urlsplit, urlunsplit, quote, quote_plus, urljoin, urlparse
from botBase import botBase
botBase = botBase()

class ProgressPercentage(object):
    def __init__(self, filename):
        self._filename = filename
        self._size = float(os.path.getsize(filename))
        self._seen_so_far = 0
        self._lock = threading.Lock()

    def __call__(self, bytes_amount):
        # To simplify the synchronization of threads
        with self._lock:
            self._seen_so_far += bytes_amount
            percentage = (self._seen_so_far / self._size) * 100
            print(f"\r{self._filename}  {self._seen_so_far}/{self._size}  ({percentage:.2f}%)", end="")


class HTMLComparator:
    def __init__(self, new_fullpath, old_fullpath, bucket_name):
        self.new_fullpath = new_fullpath
        self.old_fullpath = old_fullpath
        self.bucket_name = bucket_name
    
    def download_html_files_samba(self):
        """
        Function to download files from Samba server using configured credentials
        """
        global op_queue_push
        connected = False
        count = 1
        max_retries = 3

        while not connected and count <= max_retries:
            try:
                botBase.log_writing("download_html_files_samba", 'INFO')

                folder_path = 'downloaded_files'
                if not os.path.exists(folder_path):
                    os.makedirs(folder_path)

                # Local file paths
                new_filename = os.path.join(folder_path, os.path.basename(self.new_fullpath))
                old_filename = os.path.join(folder_path, os.path.basename(self.old_fullpath))

                # Register session
                smbclient.register_session(SERVER_IP, username=SERVER_USERNAME, password=SERVER_PASSWORD)

                # === Extract folder and file paths ===
                full_paths = [self.new_fullpath, self.old_fullpath]
                missing_folders = []
                missing_files = []

                for path in full_paths:
                    folder_rel_path = os.path.dirname(path).replace("\\", "/")
                    file_name = os.path.basename(path)

                    samba_folder_path = f"//{SERVER_IP}/{SERVER_SHARE}/{folder_rel_path}"
                    samba_file_path = f"{samba_folder_path}/{file_name}"

                    if not smbclient.path.exists(samba_folder_path):
                        missing_folders.append(folder_rel_path)
                        continue  # Skip file check if folder doesn't exist

                    if not smbclient.path.exists(samba_file_path):
                        missing_files.append(file_name)

                # === Handle missing folders ===
                if missing_folders:
                    status_scenario = f"Folder(s) not found on Samba server: {', '.join(missing_folders)}. Please verify the input folder path(s)."
                    botBase.log_writing(status_scenario, "ERROR")
                    print("status_scenario:", status_scenario)
                    process_final_status = 'Failure'
                    self.generate_failure_output(process_final_status, status_scenario)
                    op_queue_push = True
                    return []

                # === Handle missing files ===
                if missing_files:
                    status_scenario = f"The file(s) is not available in the Samba server, so can't download: {', '.join(missing_files)}.Please verify the input file name(s)."
                    botBase.log_writing(status_scenario, "ERROR")
                    print("status_scenario:", status_scenario)
                    process_final_status = 'Failure'
                    self.generate_failure_output(process_final_status, status_scenario)
                    op_queue_push = True
                    return []

                # === Proceed to download ===
                new_remote_file_path = f"//{SERVER_IP}/{SERVER_SHARE}/{self.new_fullpath}"
                old_remote_file_path = f"//{SERVER_IP}/{SERVER_SHARE}/{self.old_fullpath}"

                with open(new_filename, "wb") as new_file:
                    with smbclient.open_file(new_remote_file_path, mode="rb") as remote_file:
                        new_file.write(remote_file.read())
                botBase.log_writing(f"{new_filename} downloaded successfully", "INFO")

                with open(old_filename, "wb") as old_file:
                    with smbclient.open_file(old_remote_file_path, mode="rb") as remote_file:
                        old_file.write(remote_file.read())
                botBase.log_writing(f"{old_filename} downloaded successfully", "INFO")

                connected = True

            except FileNotFoundError as e:
                status_scenario = 'File not found on Samba server during download'
                error_message = f"[ERROR] {status_scenario}: {str(e)}"
                botBase.log_writing(error_message, "ERROR")
                print("error_message::", error_message)
                self.generate_failure_output(process_final_status, status_scenario)
                op_queue_push = True
                return []

            except PermissionError as e:
                status_scenario = 'Access denied while accessing Samba server or file'
                error_message = f"[ERROR] {status_scenario}: {str(e)}"
                botBase.log_writing(error_message, "ERROR")
                print("error_message:", error_message)
                self.generate_failure_output(process_final_status, status_scenario)
                op_queue_push = True
                return []

            except Exception as e:
                error_message = f"[ERROR] Exception during Samba file download: {str(e)}"
                botBase.log_writing(error_message, "ERROR")
                self.generate_failure_output(process_final_status, status_scenario)
                op_queue_push = True
                print("error_message:", error_message)
                count += 1

                if count > max_retries:
                    botBase.output_writer_error(f'Exception in download_html_files_samba:::{str(e)}.Max retries reached.', "10006", bot_start_time,
                                                                    input_dict, PID, inputJsondata, '', messageid, conn)  
                    op_queue_push = True
                    botBase.log_writing("Max retries reached. Samba service issue persists.", "ERROR")
                    return []

        if connected:
            botBase.log_writing("Files downloaded successfully from Samba", "INFO")

        return [new_filename, old_filename]

    def download_html_files(self):
        """
        Function to download files from S3 using IAM role or default credentials
        """

        global op_queue_push
        connected = False
        count = 1
        max_retries = 3


        if ROLE_BASED is True or (isinstance(ROLE_BASED, str) and ROLE_BASED.lower() == 'true'):
            botBase.log_writing("-------ROLE_BASED = True ----------- ", "INFO")
            botBase.log_writing("[download_html_files] Using role-based authentication for AWS S3", "INFO")
            print("[download_html_files] Using role-based authentication for AWS S3")
            s3 = boto3.client("s3", region_name=REGION)
        else:
            botBase.log_writing("-------ROLE_BASED = False ----------- ", "INFO")
            botBase.log_writing("[download_html_files] Using non-role-based authentication for AWS S3", "INFO")
            print("[download_html_files] Using non-role-based authentication for AWS S3")
            s3 = boto3.client(
                's3',
                region_name=REGION,
                aws_access_key_id=ACCESS_KEY,
                aws_secret_access_key=SECRET_KEY
            )


        while not connected and count <= max_retries:
            try:
                botBase.log_writing("download_html_files", 'INFO')
                folder_path = 'downloaded_files'
                if not os.path.exists(folder_path):
                    os.makedirs(folder_path)

                new_filename = f"{folder_path}/{self.new_fullpath.split('/')[-1]}"
                old_filename = f"{folder_path}/{self.old_fullpath.split('/')[-1]}"

                s3.download_file(BUCKET_NAME, self.new_fullpath, new_filename)
                botBase.log_writing(f"{new_filename} downloaded successfully", "INFO")

                s3.download_file(BUCKET_NAME, self.old_fullpath, old_filename)
                botBase.log_writing(f"{old_filename} downloaded successfully", "INFO")

                connected = True

            # Handled Client Exception by Gowri on 15.02.2025 
            except ClientError as e:
                error_code = e.response['Error']['Code']
                http_status = e.response['ResponseMetadata']['HTTPStatusCode']
                error_message = e.response['Error']['Message']

                botBase.log_writing(f"S3 ClientError: {error_code} (HTTP {http_status}) - {error_message}", "ERROR")

                if http_status == 404:
                    process_final_status = 'Failure'
                    status_scenario = 'There are not enough HTML files available in S3 for comparison'
                    self.generate_failure_output(process_final_status,status_scenario)
                    op_queue_push = True
                    return []
                
                elif http_status == 403:
                    botBase.log_writing(f"Error 403 - {str(e)}", "ERROR")
                    botBase.output_writer_error('Exception in S3-download_files : Access denied to S3 bucket or file.' , "10006", bot_start_time,
                                                                    input_dict, PID, inputJsondata, '', messageid, conn)  
                    op_queue_push = True
                    return []

                elif http_status in [500, 503]:
                    botBase.log_writing(f"Error {http_status}: AWS service issue. Retrying attempt {count}/{max_retries}...", "ERROR")
                    count += 1
                    if count > max_retries:
                        botBase.log_writing("Max retries reached. AWS service issue persists.", "ERROR")
                        botBase.output_writer_error(f"Exception in S3-download_files:::{str(e)}", 
                                                    "10006", bot_start_time, input_dict, PID, inputJsondata, '', messageid, conn)  
                        op_queue_push = True
                        return []
                

            except Exception as e:
                print(e)
                count += 1  # Move inside exception block
                if count > max_retries:
                    botBase.output_writer_error('Exception in S3-download_files:::' + str(e), "10006", bot_start_time,
                                                                    input_dict, PID, inputJsondata, '', messageid, conn)  
                    op_queue_push = True
                    return []

        if connected:
            botBase.log_writing("Files downloaded successfully from S3", "INFO")
        return [new_filename, old_filename]


    def download_html_files_old(self):
        '''Download the html files from the folder'''

        if ROLE_BASED is True or (isinstance(ROLE_BASED, str) and ROLE_BASED.lower() == 'true'):
            botBase.log_writing("-------ROLE_BASED = True -----------", "INFO")
            print("Using role-based authentication for AWS S3")
            botBase.log_writing("Using role-based authentication for AWS S3", "INFO")
            s3 = boto3.resource('s3',region_name=REGION)
        else:
            botBase.log_writing("-------ROLE_BASED = False -----------", "INFO")
            print("Using access key-based authentication for AWS S3")
            botBase.log_writing("Using access key-based authentication for AWS S3", "INFO")
            s3 = boto3.resource(
                's3',
                region_name=REGION,
                aws_access_key_id=ACCESS_KEY,
                aws_secret_access_key=SECRET_KEY
            )

        try:
            botBase.log_writing("download_html_files", 'INFO')
            folder_path = 'downloaded_files'
            if not os.path.exists(folder_path):
                os.makedirs(folder_path)

            new_filename = f"{folder_path}/{self.new_fullpath.split('/')[-1]}"
            old_filename = f"{folder_path}/{self.old_fullpath.split('/')[-1]}"

            s3.download_file(BUCKET_NAME, self.new_fullpath, new_filename)
            s3.download_file(BUCKET_NAME, self.old_fullpath, old_filename)

            return [new_filename, old_filename]
        except Exception as e:
            print("Error:", e)
            botBase.log_writing(f"Error in download_html_files:{str(e)}", 'ERROR')
            botBase.output_writer_error(f"Error in download_html_files:{str(e)}", "1008", bot_start_time,input_dict, PID, inputJsondata, '', messageid, conn)
            global op_queue_push
            return []


    def extract_visible_text(self, html_content):
        '''Parse HTML using BeautifulSoup'''
        soup = BeautifulSoup(html_content, 'html.parser')
        visible_text = soup.get_text(separator=" ", strip=True)
        return visible_text.strip()


    def extract_links(self, html_content, URL):
        '''Extract links from HTML content, including various tags'''
        soup = BeautifulSoup(html_content, 'html.parser')

        # Initialize a set to avoid duplicate links
        links = set()

        # Extract links from <a> tags
        for a in soup.find_all('a', href=True):
            links.add(urlparse(a['href']).geturl())

        # Extract links from <link> tags
        for link in soup.find_all('link', href=True):
            links.add(urlparse(link['href']).geturl())

        # Extract links from <script> tags (if you want to capture src attributes)
        for script in soup.find_all('script', src=True):
            links.add(urlparse(script['src']).geturl())

        # Extract links from <img> tags (if you want to capture src attributes)
        for img in soup.find_all('img', src=True):
            links.add(urlparse(img['src']).geturl())

        # Extract links from <area> tags (for image maps)
        for area in soup.find_all('area', href=True):
            links.add(urlparse(area['href']).geturl())

        # Extract links from <iframe> tags
        for iframe in soup.find_all('iframe', src=True):
            links.add(urlparse(iframe['src']).geturl())
        
        # Convert the set back to a list and return
        return list(links)
        
    
    def compare_html_content(self, html_content_1, html_content_2):
        '''Extract visible text content from HTML using BeautifulSoup and count changes'''

        # Parse the HTML content
        soup_1 = BeautifulSoup(html_content_1, 'html.parser')
        visible_text_1 = soup_1.get_text(separator=' ')

        soup_2 = BeautifulSoup(html_content_2, 'html.parser')
        visible_text_2 = soup_2.get_text(separator=' ')

        # Initialize additions and deletions counts
        added_count = []
        removed_count = []

        # Compare the visible texts and find differences
        if visible_text_1 != visible_text_2:
            # Use unified_diff to find differences
            diff = list(unified_diff(visible_text_1.splitlines(), visible_text_2.splitlines()))
            
            # Count additions and deletions
            for line in diff:
                if line.startswith('+ '):
                    added_count.append(line[2:])  # Store the added line without '+ '
                elif line.startswith('- '):
                    removed_count.append(line[2:])  # Store the removed line without '- '

            # Calculate counts
            additions_count = len(added_count)
            deletions_count = len(removed_count)

            # Format the changes count string
            html_changes_count = f"Addition-{additions_count};Deletion-{deletions_count}"
            print("Changes count::::::::", html_changes_count)

            return 'Yes', html_changes_count  # Change detected with counts
        else:
            return 'No', "Addition-0;Deletion-0"  # No
        

    def generate_signed_url(self, object_key, expiration_time_seconds):
        """Generate a signed URL that allows access to the specified object for the duration specified by expiration_time_seconds.
        After that time, the URL will expire."""
        botBase.log_writing('Calling generate_signed_url::::::::', "INFO")
        try:
            global op_queue_push
            if ROLE_BASED is True or (isinstance(ROLE_BASED, str) and ROLE_BASED.lower() == 'true'):
                botBase.log_writing("[generate_signed_url] ROLE_BASED = True", "INFO")
                print("[generate_signed_url] Using role-based authentication for AWS S3")
                botBase.log_writing("[generate_signed_url] Using role-based authentication for AWS S3", "INFO")
                s3_client = boto3.client('s3',
                                        region_name=REGION,
                                        config=boto3.session.Config(signature_version='s3v4'))
            else:
                botBase.log_writing("[generate_signed_url] ROLE_BASED = False", "INFO")
                print("[generate_signed_url] Using access key-based authentication for AWS S3")
                botBase.log_writing("[generate_signed_url] Using access key-based authentication for AWS S3", "INFO")

                s3_client = boto3.client('s3',
                                        aws_access_key_id=ACCESS_KEY,
                                        aws_secret_access_key=SECRET_KEY,
                                        region_name=REGION,
                                        config=boto3.session.Config(signature_version='s3v4'))

            #added by Vikram 22-10-2024
            params = {
                'Bucket': BUCKET_NAME,
                'Key': object_key,
                'ResponseContentDisposition': 'inline',  # This ensures the object opens in the browser
                'ResponseContentType' :'text/html' #Force Content-Type to HTML
            }
            signed_url = s3_client.generate_presigned_url(
                'get_object',
                Params=params,
                ExpiresIn=expiration_time_seconds
            )
            return signed_url
        except ClientError as e:
            print("Error generating signed URL:", e)
            botBase.log_writing(f'Error generating signed URL: {str(e)}', "ERROR")
            botBase.output_writer_error(f"Error generating signed URL: {str(e)}", "10004", bot_start_time,input_dict, PID, inputJsondata, '', messageid, conn)
            op_queue_push=True
            return None
        
        except Exception as e:
            print(f"Unexpected error: {e}")
            botBase.log_writing(f'Error generating signed URL: {str(e)}', "ERROR")
            botBase.output_writer_error(f"Unexpected error in generate_signed_url: {str(e)}", "10005", bot_start_time,input_dict, PID, inputJsondata, '', messageid, conn)
            op_queue_push=True
            return None

            
    def S3_folder_naming(self,input_string):
        
        """input string, presumably to extract a "batch ID" from it.
        The input string is expected to be in one of two specific formats, separated by underscores (_).
        does not match either expected length, a default value 'REF_ID' is returned."""
        
        try:
            global op_queue_push
            split_parts = input_string.split("_")
            if len(split_parts) == 9:
                bot_id, batch_id, user_id, *date_parts_and_utc, rest = split_parts
                
                year, month, day, utc_timestamp = None, None, None, None
                if len(date_parts_and_utc) >= 4:
                    year, month, day, utc_timestamp, *extra_parts = date_parts_and_utc
                return batch_id
            elif len(split_parts) == 8:
                bot_id = split_parts[0]
                batch_id = split_parts[1]
                utc_timestamp = split_parts[5]
                return batch_id
            else:
                return 'REF_ID'
        except Exception as e:
            print("Error generating signed URL:", e)
            botBase.log_writing(f'Error S3_folder_naming: {str(e)}', "ERROR")
            botBase.output_writer_error(f"Error S3_folder_naming: {str(e)}", "10007", bot_start_time,input_dict, PID, inputJsondata, '', messageid, conn)
            op_queue_push=True
            return None


    def compare_text_values(self, text_1, text_2):

        '''Compare the text values'''

        if text_1 != text_2:
            return 'Yes'  # Change detected
        else:
            return 'No'  # No change
    

    # Added by Gowri on 29.04.2025  
    def clean_text(self, text):
        if not text:
            return ""
        text = text.replace('\xad', '')  # Remove soft hyphens
        text = re.sub(r'[\u200b\u200e\u202c\u202a]', '', text)  # Remove invisible characters
        return ' '.join(text.split())  # Normalize whitespace


    # Added by Gowri on 30-04-2025
    def remove_control_characters(self,text):
        # Replace backslashes with forward slashes
        text = re.sub(r'\\', '/', text)
        
        # Remove all control characters except \t, \n, \r
        text = re.sub(r'[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]', '', text)
        
        # Optional: strip leading/trailing whitespace
        return text.strip()
    

    def compare_html_text(self):
        try:
            botBase.log_writing("compare_html_text", 'INFO')

            # Use the paths returned by download_html_files
            new_file_path = self.new_fullpath.split('/')[-1]  # Get the filename
            old_file_path = self.old_fullpath.split('/')[-1]  # Get the filename

            # Construct full paths for the downloaded files
            new_full_path = f"downloaded_files/{new_file_path}"
            old_full_path = f"downloaded_files/{old_file_path}"

            # Modified by Gowri on 30-04-2025
            # Read HTML content from files
            with open(new_full_path, 'r', encoding='utf-8') as f1, open(old_full_path, 'r', encoding='utf-8') as f2:
                new_html = self.remove_control_characters(f1.read())
                old_html = self.remove_control_characters(f2.read())
                
            old_number_of_lines = len(old_html.splitlines(keepends=True))
            new_number_of_lines = len(new_html.splitlines(keepends=True))
            
            html_diff_status,html_changes_count = self.compare_html_content(old_html, new_html)
            print("html_changes_count:::::::::::",html_changes_count)

            # Parsing HTML using BeautifulSoup
            old_soup = BeautifulSoup(old_html, 'html.parser')
            new_soup = BeautifulSoup(new_html, 'html.parser')


            # Extracting human-readable text from the body
            old_text = old_soup.body.get_text(separator="\n", strip=True)
            new_text = new_soup.body.get_text(separator="\n", strip=True)

            # Modified by Gowri on 29.04.2025
            # Split to lines and clean each line individually
            old_text_lines = [
                self.clean_text(line) for line in old_text.splitlines() if "cookie" not in line.lower()
            ]
            new_text_lines = [
                self.clean_text(line) for line in new_text.splitlines() if "cookie" not in line.lower()
            ]


            # Using difflib to find differences in text content
            diff = list(difflib.ndiff(old_text_lines, new_text_lines))

            
            # Extract base URL from provided link
            # base_url = URL[:URL.index('.com') + 4]  # Base URL until .com
            parsed_url = urlparse(URL)

            # Construct the base URL
            base_url = f"{parsed_url.scheme}://{parsed_url.netloc}"
            print("BASE URL::",base_url)
        
            additions = []
            deletions = []
            modified_added_links = []
            # Store modified links here
        

            for line in diff:
                if line.startswith('+ '):
                    additions.append(line[2:])  # Content added in new file
                elif line.startswith('- '):
                    deletions.append(line[2:])  # Content removed from old file

            # Count of additions and deletions
            additions_count = len(additions)
            deletions_count = len(deletions)

            # Debugging output
            print(f"Additions: {additions}, Count: {additions_count}")
            print(f"Deletions: {deletions}, Count: {deletions_count}")

            # Highlight additions in green and deletions in red
            new_highlighted_text = new_html
            old_highlighted_text = old_html

            for added_content in additions:
                new_html = new_html.replace(
                    added_content,
                    f'<span style="background-color: #00FF00" class="diff-html-Added" title="Added" alt="Added">{added_content}</span>',
                    1
                )

            combined_html = new_html

            for deleted_content, added_content in zip(deletions, additions):
                deleted_span = f'<span style="background-color: #FF0000" class="diff-html-removed" title="Removed" alt="Removed">{deleted_content}</span>'
                if added_content in combined_html:
                    combined_html = combined_html.replace(
                        added_content,
                        f'{deleted_span} {added_content}', 
                        1  
                    )

            for deleted_content in deletions[len(additions):]:
                deleted_span = f'<span style="background-color: #FF0000" class="diff-html-removed" title="Removed" alt="Removed">{deleted_content}</span>'
                combined_html += f'<br>{deleted_span}'

            for added_content in additions[len(deletions):]:
                added_span = f'<span style="background-color: #00FF00" class="diff-html-added" title="Added" alt="Added">{added_content}</span>'
                combined_html += f'<br>{added_span}'

            # Modified by Gowri on 29.04.2025
            old_links = {urljoin(base_url, a['href']) for a in old_soup.find_all('a', href=True)}
            new_links = {urljoin(base_url, a['href']) for a in new_soup.find_all('a', href=True)}
            
            print("NEW LINKS::::", new_links)
            
            added_links = new_links - old_links
            removed_links = old_links - new_links
            
            #commented by Gowri on 16.04.2025
            # Process added links to handle relative URLs and store them correctly
            # for link in added_links:
                # modified_link = None
                # if link.startswith('/') or link.startswith('#'): 
                    # modified_link = base_url + link if link.startswith('/') else base_url + link[1:]
                    #modified_added_links.append(modified_link)  # Store the modified link

                # else:
                    # modified_link = link
                    #modified_added_links.append(link)  # Store original absolute links as well
            
                #Apply safe encoding
                # encoded_link = self.safe_encode_url(modified_link)
                # modified_added_links.append(encoded_link)
                #print(f"Modified link: {modified_link}")
            
            # Added by Gowri on 21.04.2025  row no : 367 - 378 & 388 - 397
            # Process added links
            for link in added_links:
                try:
                    if not link:
                        modified_added_links.append(link)
                        continue

                    link = html.unescape(link)

                    # Encode only if space exists
                    if ' ' in link:
                        link = quote(link.strip(), safe=':/?=&')

                    # Use absolute as-is, else join with base_url
                    if link.startswith('http://') or link.startswith('https://'):
                        final_link = link
                    else:
                        base = base_url if base_url.endswith('/') else base_url + '/'
                        final_link = urljoin(base, link)
                    
                    modified_added_links.append(final_link)

                except Exception as e:
                    print(f"Failed to process link: {link}")
                    botBase.log_writing(f"Failed to process link: {link}", 'ERROR')
                    modified_added_links.append(link)
                    
            #Added by Gowri on 29.04.2025
            added_links = {link for link in added_links if link.strip()}
            removed_links = {link for link in removed_links if link.strip()}

            url_changes_count = f"Addition-{len(added_links)};Deletion-{len(removed_links)}"
            print("url changes count::",url_changes_count)

            print(f"Added links: {modified_added_links}")  # Print modified links correctly
            print(f"Removed links: {removed_links}")
            
            new_soup.body.clear()
            old_soup.body.clear()

            new_soup.body.append(BeautifulSoup(combined_html, 'html.parser'))
            old_soup.body.append(BeautifulSoup(old_highlighted_text, 'html.parser'))

            with open(new_full_path, 'w', encoding='utf-8') as f_new:
                f_new.write(str(new_soup.prettify()))
            

            botBase.log_writing("Bot has been successfully highlighted the text values", 'INFO')
                # Prepare the result with pipe-separated values
            result = {
                'html_diff_status': 'Yes' if old_soup.prettify() != new_soup.prettify() else 'No',
                'text_diff_status': 'Yes' if additions_count > 0 or deletions_count > 0 else 'No',
                'text_changes_count': f"Addition-{additions_count};Deletion-{deletions_count}",
                'url_changes_count': url_changes_count,
                'html_changes_count' : html_changes_count,
                'text_added_content': ' | '.join(additions),  # Joining added lines with '|'
                'text_removed_content': ' | '.join(deletions),  # Joining removed lines with '|'
                'added_links': ' | '.join(modified_added_links),  # Joining added links with '|'
                'removed_links': ' | '.join(removed_links),  # Joining removed links with '|'
                'old_number_of_lines': old_number_of_lines,
                'new_number_of_lines': new_number_of_lines
            }
            

            # Upload updated HTML files to S3
            #s3_client = boto3.client('s3', aws_access_key_id=ACCESS_KEY, aws_secret_access_key=SECRET_KEY, region_name=REGION)
            batch_id = self.S3_folder_naming(REF_ID)
            folder_path = f"{FOLDER_NAME}/{batch_id}"

            new_s3_path = self.s3_upload_file(folder_path,new_full_path)

            if new_s3_path is None:
                return {}

            # Upload old HTML file to S3
            folder_path = f"{FOLDER_NAME}/{batch_id}"
            old_s3_path = self.s3_upload_file(folder_path, old_full_path)

            if old_s3_path is None:
                return {}
     
            # Generate signed URLs for the uploaded files
            # new_signed_url = self.generate_signed_url(BUCKET_NAME, new_s3_path, EXPIRATION_TIME, REGION)
            if CSP_NAME and CSP_NAME.lower() == 'aws':
                new_signed_url = self.generate_signed_url(new_s3_path, EXPIRATION_TIME)
                botBase.log_writing("S3 signed URL generated successfully for **new file**", "INFO")
            elif CSP_NAME and CSP_NAME.lower() in ['local', 'localinfra']:
                new_signed_url = self.generate_samba_signed_url(new_s3_path)
                botBase.log_writing("Samba signed URL generated successfully for **new file**", "INFO")
            else:
                print(f"[ERROR] Unsupported CSP_NAME: {CSP_NAME}")
                botBase.log_writing(f"[ERROR] Unsupported CSP_NAME: {CSP_NAME}", "ERROR")
                botBase.output_writer_error(f"[ERROR] Unsupported CSP_NAME: {CSP_NAME}", "1234", bot_start_time,
                                        input_dict, PID, inputJsondata, '', messageid, conn)
                op_queue_push = True
                return {}
                
            result['diff_highlighted_s3_signedurl'] = new_signed_url
            botBase.log_writing("diff_highlighted_s3_signedurl created sucessfully and uploaded to s3 bucket:::::::::", 'INFO')

            return result

        except Exception as e:
            print("Error:", e)
            botBase.log_writing("Error in compare_html_text", 'ERROR')
            return {
                'html_diff_status': 'No',
                'text_diff_status': 'No',
                'text_changes_count': 'No changes',
                'url_changes_count': 'No changes',
                'html_changes_count' : 'No changes',
                'text_added_content': '',
                'text_removed_content': '',
                'added_links': '',
                'removed_links': '',
                'diff_highlighted_s3_signedurl': '',
                'old_number_of_lines':'',
                'new_number_of_lines':''
            }
        

    def s3_upload_file(self,temp_s3_folder_name,file_to_upload):
        """
        Function to upload files to S3 using IAM role or default credentials
        """
        print("Calling s3 upload function......")
        global op_queue_push
        connected = False
        count = 1
        path = ""
        
        # Extract only the filename
        filename = os.path.basename(file_to_upload)
        
        if ROLE_BASED is True or (isinstance(ROLE_BASED, str) and ROLE_BASED.lower() == 'true'):
            botBase.log_writing("[s3_upload_file] ROLE_BASED = True", "INFO")
            print("[s3_upload_file] Using role-based authentication for AWS S3")
            botBase.log_writing("[s3_upload_file] Using role-based authentication for AWS S3", "INFO")
            s3 = boto3.resource("s3", region_name=REGION)
        else:
            botBase.log_writing("[s3_upload_file] ROLE_BASED = False", "INFO")
            print("[s3_upload_file] Using access key-based authentication for AWS S3")
            botBase.log_writing("[s3_upload_file] Using access key-based authentication for AWS S3", "INFO")
            s3 = boto3.resource(
                's3',
                region_name=REGION,
                aws_access_key_id=ACCESS_KEY,
                aws_secret_access_key=SECRET_KEY
            )


        while not connected:
            try:
                bucket = s3.Bucket(BUCKET_NAME)
                print(f'Uploading {filename} to Amazon S3 bucket {BUCKET_NAME}')
                botBase.log_writing(f'Uploading {filename} to Amazon S3 bucket {BUCKET_NAME}', "INFO")

                path = f"{temp_s3_folder_name}/{filename}"

                bucket.upload_file(file_to_upload, path, Callback=ProgressPercentage(file_to_upload))
                connected = True
            except Exception as e:
                print(e)
                count += 1
                if count <= 3:
                    continue
                else:
                    botBase.log_writing(f'Exception in S3-upload_files::: {str(e)}', "ERROR")
                    botBase.output_writer_error('Exception in S3-upload_files:::' + str(e), "10006", bot_start_time,
                                                                    input_dict, PID, inputJsondata, '', messageid, conn)  
                    op_queue_push=True
                    return None

        if connected:
            botBase.log_writing("File uploaded successfully to S3", "INFO")
        return path



    def samba_upload_file(self,temp_s3_folder_name, file_to_upload):
        """
        Upload file to Samba share with full error handling.
        """
        print("Calling samba upload function......")
        global op_queue_push

        connected = False
        count = 1
        path = ""

        filename = os.path.basename(file_to_upload)
        path = f"{temp_s3_folder_name}/{filename}".replace("\\", "/")

        # Step 1: Register Samba session
        try:
            register_session(SERVER_IP, username=SERVER_USERNAME, password=SERVER_PASSWORD)
        except Exception as e:
            err_msg = f"ERROR: Failed to register Samba session: {str(e)}"
            botBase.log_writing(err_msg, "ERROR")
            botBase.output_writer_error(err_msg, "101", bot_start_time, input_dict, PID, inputJsondata, '', messageid, conn)
            op_queue_push = True
            return None

        while not connected:
            try:
                # Step 2: Check if local file exists
                if not os.path.exists(file_to_upload):
                    err_msg = f"ERROR: Local file not found: {file_to_upload}"
                    botBase.log_writing(err_msg, "ERROR")
                    botBase.output_writer_error(err_msg, "102", bot_start_time, input_dict, PID, inputJsondata, '', messageid, conn)
                    op_queue_push = True
                    return None

                print(f"Uploading {filename} to Samba server")
                botBase.log_writing(f"Uploading {filename} to Samba share at {SERVER_IP}", "INFO")

                remote_file_path = f"//{SERVER_IP}/{SERVER_SHARE}/{path}".replace("\\", "/")
                remote_dir_path = os.path.dirname(remote_file_path)

                # Step 3: Create remote directories if not exist
                try:
                    print(f"[INFO] Starting Samba remote directory creation: {remote_dir_path}")
                    dir_parts = remote_dir_path.split("/")
                    current_path = f"//{SERVER_IP}/{SERVER_SHARE}"
                    print(f"[INFO] Base Samba path: {current_path}")
                    
                    for part in dir_parts[len(current_path.split("/")):]:
                        current_path = f"{current_path}/{part}"
                        print(f"[INFO] Checking existence of: {current_path}")
                        try:
                            samba_files = smbclient.listdir(current_path)
                            print(f"[INFO] Exists - Files in '{current_path}': {samba_files}")
                        except Exception as mkdir_check_err:
                            print(f"[INFO] Directory does not exist: {current_path}, will attempt to create it. Error: {str(mkdir_check_err)}")
                            try:
                                smbclient.mkdir(current_path)
                                print(f"[INFO] Created directory: {current_path}")
                                botBase.log_writing(f"Created Samba directory: {current_path}", "INFO")
                            except Exception as mkdir_fail_err:
                                err_msg = f"ERROR: Failed to create Samba directory '{current_path}': {str(mkdir_fail_err)}"
                                print(f"[ERROR] {err_msg}")
                                botBase.log_writing(err_msg, "ERROR")
                                botBase.output_writer_error(err_msg, "103", bot_start_time, input_dict, PID, inputJsondata, '', messageid, conn)
                                op_queue_push = True
                                return None
                    print(f"[INFO] Completed Samba remote directory creation: {remote_dir_path}")
                except Exception as dir_err:
                    err_msg = f"ERROR: Failed during directory creation logic: {str(dir_err)}"
                    print(f"[ERROR] {err_msg}")
                    botBase.log_writing(err_msg, "ERROR")
                    botBase.output_writer_error(err_msg, "104", bot_start_time, input_dict, PID, inputJsondata, '', messageid, conn)
                    op_queue_push = True
                    return None


                # Step 4: Upload the file
                try:
                    with open(file_to_upload, "rb") as local_file:
                        with open_file(remote_file_path, mode="wb") as remote_file:
                            remote_file.write(local_file.read())
                except Exception as write_err:
                    err_msg = f"ERROR: Failed while writing to Samba file '{remote_file_path}': {str(write_err)}"
                    botBase.log_writing(err_msg, "ERROR")
                    botBase.output_writer_error(err_msg, "105", bot_start_time, input_dict, PID, inputJsondata, '', messageid, conn)
                    op_queue_push = True
                    return None

                botBase.log_writing("File uploaded successfully to Samba", "INFO")
                connected = True

            except Exception as e:
                err_msg = f"Exception in Samba-upload_files (retry {count}): {str(e)}"
                botBase.log_writing(err_msg, "ERROR")
                count += 1
                if count > 3:
                    botBase.output_writer_error(err_msg, "106", bot_start_time, input_dict, PID, inputJsondata, '', messageid, conn)
                    op_queue_push = True
                    return None

        if connected:
            botBase.log_writing("File uploaded successfully to SAMBA", "INFO")
        
        return path if connected else None


    def compare_html_files(self, html_files):
        '''Compare the last two latest html files'''
        try:
            html_contents = []
            for html_file in html_files:
                with open(html_file, 'r', encoding='utf-8') as file:
                    html_contents.append(file.read())

            visible_texts = [self.extract_visible_text(html_content) for html_content in html_contents]

            html_diff_status = self.compare_html_content(html_contents[1], html_contents[0])
            text_diff_status = self.compare_text_values(visible_texts[1], visible_texts[0])

            return html_diff_status, text_diff_status
        except Exception as e:
            print("Error:", e)
            return 'No', 'No'

    def compare_text_values(self, text_1, text_2):
        '''Compare the text values'''
        if text_1 != text_2:
            return 'Yes'  # Change detected
        else:
            return 'No'  # No change

    def calculate_processing_time(self):
        '''Calculate Processing Time'''
        end_time = datetime.now()
        processing_time = end_time - b_start_time
        hours = processing_time.seconds // 3600
        minutes = (processing_time.seconds // 60) % 60
        seconds = processing_time.seconds % 60
        time_string = f"{seconds} sec"
        return time_string.strip()

    def delete_files(self, files):
        '''Delete downloaded files'''
        for file in files:
            os.remove(file)


    def generate_failure_output(self, final_status, status_scenario):
        try:
            global Output_Write_Flag
            global op_write_flag
            global op_queue_push

            output_list = []

            e_time = datetime.now()
            e_time = re.sub('\.[^<]*?$', '', str(e_time))

            output = {
                "bot_start_time": bot_start_time,
                "bot_end_time": e_time,
                "bot_name": Bot_name,
                "version": Version,
                "mobito_2_0_version": mobito_2_0_version,
                "processed_ip": PROCESSED_IP,
                "processing_time": html_comparator.calculate_processing_time(),
                "InputId": INPUTID,
                "OutputId": OUTPUTID,
                "mobid": MOBID,
                "clientid": CLIENTID,
                "ref_id": REF_ID,
                "in_id": IN_ID,
                "url": URL,
                "hashcode": HASHCODE,
                "md5_hash_url": HASHCODE,
                "new_signeds3url": NEW_SIGNEDS3URL,
                "new_fullpath": NEW_FULPATH,
                "new_filename": NEW_FILENAME,
                "new_foldername": NEW_FOLDERNAME,
                "old_fullpath": OLD_FULLPATH,
                "old_filename": OLD_FILENAME,
                "old_folderpath": OLD_FOLDERPATH,
                "old_signeds3url": OLD_SIGNEDS3URL,
                "html_diff_status": '',
                "text_diff_status": '',
                "cleanse_diff_status": '',
                "process_final_status": final_status,
                "status_scenario": status_scenario,
                "text_changes_count": '',
                "url_changes_count": '',
                "html_changes_count":'',
                "text_added_content": '',
                "text_removed_content": '',
                "added_links": '',
                "removed_links": '',
                "old_number_of_lines":'',
                "new_number_of_lines":'',
                "diff_highlighted_s3_signedurl": '',
                "redirected_url": REDIRECTED_URL,
                "md5_hashcode_redirectedurl": MD5_HASHCODE_REDIRECTEDURL,
                "new_website_status":NEW_WEBSITE_STATUS,
                "project_name": PROJECT_NAME,
                "old_website_status": OLD_WEBSITE_STATUS,
                "old_page_date": OLD_PAGE_DATE,
                "input_comparison_date": INPUT_COMPARISON_DATE
            }

            output_list.append(output)
            Output_Write_Flag=True

            if op_write_flag == 0:
                # Generate the output
                botBase.log_writing('generate_output Starts!!!', 'INFO')
                botBase.generate_output(output_list, '', input_dict, 'COMPLETED',inputJsondata,'', PID, bot_start_time, messageid, conn)
                op_write_flag = 1
                op_queue_push=True

        except Exception as e:
            botBase.log_writing('Error in generate_failure_output Function!!!',+ str(e), 'ERROR')
            botBase.output_writer_error('Error in generate_failure_output function',+ str(e), "1010", bot_start_time,input_dict, PID, inputJsondata, '', messageid, conn)
            op_queue_push=True


    def wcm_html_text_compare(self):
        try:
            global Output_Write_Flag
            global op_write_flag
            global op_queue_push
            flag_1 = False

            output_list = []
            
            # Input validation added by Gowri on 15.02.2025
            if not NEW_FULPATH or NEW_FULPATH == "null":
                botBase.log_writing('New full path is empty', 'ERROR')
                flag_1 =True

            elif not OLD_FULLPATH or OLD_FULLPATH == "null":
                botBase.log_writing('Old full path is empty', 'ERROR')
                flag_1 = True

            if flag_1:
                process_final_status = 'Failure'
                status_scenario = 'There are not enough HTML files available in Input for comparison'
                self.generate_failure_output(process_final_status,status_scenario)
                return
            

            html_files = html_comparator.download_html_files()
            print("Last two HTML files:", html_files)
            process_final_status = 'Success'

            if not html_files:  # Check if html_files is empty
                print("Error: No files downloaded. Exiting process.")
            
            elif len(html_files) == 2:
                #downloaded_files = self.download_html_files()
                # Calling compare_html_text() method
                comparison_result = html_comparator.compare_html_text()


                if not comparison_result:
                    return

                print("Comparison Results:", comparison_result)

                html_diff_status = comparison_result['html_diff_status']
                text_diff_status = comparison_result['text_diff_status']
                html_changes_count = comparison_result['html_changes_count']
                old_number_of_lines = comparison_result['old_number_of_lines']
                new_number_of_lines = comparison_result['new_number_of_lines']

                e_time = datetime.now()
                e_time = re.sub('\.[^<]*?$', '', str(e_time))

                # Creating output dictionary and populating fields
                output = {
                    "bot_start_time": bot_start_time,
                    "bot_end_time": e_time,
                    "bot_name": Bot_name,
                    "version": Version,
                    "mobito_2_0_version": mobito_2_0_version,
                    "processed_ip": PROCESSED_IP,
                    "processing_time": html_comparator.calculate_processing_time(),
                    "InputId": INPUTID,
                    "OutputId": OUTPUTID,
                    "mobid": MOBID,
                    "clientid": CLIENTID,
                    "ref_id": REF_ID,
                    "in_id": IN_ID,
                    "url": URL,
                    "hashcode": HASHCODE,
                    "md5_hash_url": HASHCODE,
                    "new_signeds3url": NEW_SIGNEDS3URL,
                    "new_fullpath": NEW_FULPATH,
                    "new_filename": NEW_FILENAME,
                    "new_foldername": NEW_FOLDERNAME,
                    "old_fullpath": OLD_FULLPATH,
                    "old_filename": OLD_FILENAME,
                    "old_folderpath": OLD_FOLDERPATH,
                    "old_signeds3url": OLD_SIGNEDS3URL,
                    "html_diff_status": html_diff_status,
                    "text_diff_status": text_diff_status,
                    "cleanse_diff_status": '',
                    "process_final_status": process_final_status,
                    "status_scenario": '',
                    "text_changes_count": comparison_result['text_changes_count'],
                    "url_changes_count": comparison_result['url_changes_count'],
                    "html_changes_count":html_changes_count,
                    "text_added_content": comparison_result['text_added_content'],
                    "text_removed_content": comparison_result['text_removed_content'],
                    "added_links": comparison_result['added_links'],
                    "removed_links": comparison_result['removed_links'],
                    "old_number_of_lines":old_number_of_lines,
                    "new_number_of_lines":new_number_of_lines,
                    "diff_highlighted_s3_signedurl": comparison_result['diff_highlighted_s3_signedurl'],
                    "redirected_url": REDIRECTED_URL,
                    "md5_hashcode_redirectedurl": MD5_HASHCODE_REDIRECTEDURL,
                    "new_website_status":NEW_WEBSITE_STATUS,
                    "project_name": PROJECT_NAME,
                    "old_website_status": OLD_WEBSITE_STATUS,
                    "old_page_date": OLD_PAGE_DATE,
                    "input_comparison_date": INPUT_COMPARISON_DATE
                }

                output_list.append(output)
                Output_Write_Flag=True
            
                if op_write_flag == 0:
                    botBase.log_writing('generate_output Starts!!!', 'INFO')
                    botBase.generate_output(output_list, '', input_dict, 'COMPLETED',inputJsondata,'', PID, bot_start_time, messageid, conn)
                    op_write_flag = 1
                    op_queue_push=True
                    time.sleep(1)

                self.delete_files(html_files)
            else:
                if len(html_files) < 2:
                    botBase.log_writing("Failed to download two HTML files.", 'INFO')
                    process_final_status = 'Failure'
                    status_scenario = 'There are not enough HTML files available for comparison'

                    e_time = datetime.now()
                    e_time = re.sub('\.[^<]*?$', '', str(e_time))

                    output = {
                        "bot_start_time": bot_start_time,
                        "bot_end_time": e_time,
                        "bot_name": Bot_name,
                        "version": Version,
                        "mobito_2_0_version": mobito_2_0_version,
                        "processed_ip": PROCESSED_IP,
                        "processing_time": html_comparator.calculate_processing_time(),
                        "InputId": INPUTID,
                        "OutputId": OUTPUTID,
                        "mobid": MOBID,
                        "clientid": CLIENTID,
                        "ref_id": REF_ID,
                        "in_id": IN_ID,
                        "url": URL,
                        "hashcode": HASHCODE,
                        "md5_hash_url": HASHCODE,
                        "new_signeds3url": NEW_SIGNEDS3URL,
                        "new_fullpath": NEW_FULPATH,
                        "new_filename": NEW_FILENAME,
                        "new_foldername": NEW_FOLDERNAME,
                        "old_fullpath": OLD_FULLPATH,
                        "old_filename": OLD_FILENAME,
                        "old_folderpath": OLD_FOLDERPATH,
                        "old_signeds3url": OLD_SIGNEDS3URL,
                        "html_diff_status": '',
                        "text_diff_status": '',
                        "cleanse_diff_status": '',
                        "process_final_status": process_final_status,
                        "status_scenario": status_scenario,
                        "text_changes_count": '',
                        "url_changes_count": '',
                        "html_changes_count":'',
                        "text_added_content": '',
                        "text_removed_content": '',
                        "added_links": '',
                        "removed_links": '',
                        "old_number_of_lines":'',
                        "new_number_of_lines":'',
                        "diff_highlighted_s3_signedurl": '',
                        "redirected_url": REDIRECTED_URL,
                        "md5_hashcode_redirectedurl": MD5_HASHCODE_REDIRECTEDURL,
                        "new_website_status":NEW_WEBSITE_STATUS,
                        "project_name": PROJECT_NAME,
                        "old_website_status": OLD_WEBSITE_STATUS,
                        "old_page_date": OLD_PAGE_DATE,
                        "input_comparison_date": INPUT_COMPARISON_DATE
                    }

                    output_list.append(output)
                    Output_Write_Flag=True
            
                    if op_write_flag == 0:
                        # Generate the output
                        botBase.log_writing('generate_output Starts!!!', 'INFO')
                        botBase.generate_output(output_list, '', input_dict, 'COMPLETED',inputJsondata,'', PID, bot_start_time, messageid, conn)
                        op_write_flag = 1
                        op_queue_push=True

        except Exception as e:
            print('Error:', e)
            if isinstance(e, botocore.exceptions.NoCredentialsError):
                botBase.output_writer_error('Check the S3 Credentials', "1002", bot_start_time,input_dict, PID, inputJsondata, '', messageid, conn)
                op_queue_push=True
            else:
                botBase.log_writing('Error in wcm_html_text_compare Function!!!', 'ERROR')
                botBase.output_writer_error('Error in wcm_html_text_compare', "1003", bot_start_time,input_dict, PID, inputJsondata, '', messageid, conn)
                op_queue_push=True

def mq_is_disconnected():
    try:
        with open("mq_status_flag.txt") as f:
            return f.read().strip() == "DISCONNECTED"
    except:
        return False


if __name__=="__main__":

    try:
        
        error_flag = False
        s3_config_error_msg = ""
        
        print ("Pid:"+str(os.getpid()))
        start = time.time()
        PID = str(os.getpid())	
        b_start_time = datetime.now()
        bot_start_time = re.sub(r'\.[^<]*?$', '', str(b_start_time))
        
        Bot_name= "WCM HTML Text Comparison – With Change Details"
        Version = "2.0"
        mobito_2_0_version = "1.3"
        botBase.log_writing("Script Initiated!!!", "INFO")
        botBase.log_writing("BotName::"+Bot_name, "INFO")
        botBase.log_writing("mobito2_0_version::"+mobito_2_0_version, "INFO")
        botBase.log_writing("Version::"+Version, "INFO")
        botBase.log_writing("PID::"+str(PID), "INFO")
        PROCESSED_IP = botBase.get_processed_ip()
        botBase.log_writing("PROCESSED_IP::"+str(PROCESSED_IP), "INFO")

        try:
        
            config_data = botBase.config_reader('Configuration.json')
            EXPIRATION_TIME = config_data['expiration_time']
            FOLDER_NAME = config_data['folder_name']
            MessageCount = config_data["MessageCount"]
            print('Configuration loaded successfully.') 

        except Exception as e:
        
            print(e)
            botBase.log_writing("ERROR In Reading Configuration::", "ERROR")
                      
        if not error_flag:
            # queueInfo File Reading
            try:
                queueDetails = botBase.readQueueInfo()
                print('queueDetails::',queueDetails)
                CSP_NAME = queueDetails.get("csp_name")

                if CSP_NAME.lower() == "aws":

                    # Extracting S3 and Samba configurations
                    s3_config = queueDetails.get("s3Config") or {}

                    if "s3Config" not in queueDetails:
                        error_flag = True
                        s3_config_error_msg = "s3Config key is missing in QueueInfo.json"
                        botBase.log_writing(s3_config_error_msg, "ERROR")

                    elif queueDetails.get("s3Config") is None:
                        error_flag = True
                        s3_config_error_msg = "s3Config key is present but value is null in QueueInfo.json"
                        botBase.log_writing(s3_config_error_msg, "ERROR")

                    elif isinstance(queueDetails.get("s3Config"), dict) and not queueDetails.get("s3Config"):
                        error_flag = True
                        s3_config_error_msg = "s3Config key is present but empty in QueueInfo.json"
                        botBase.log_writing(s3_config_error_msg, "ERROR")

                    else:
                        # Retrieve the 'is_role_based' value from s3_config. If not present, default to "false".
                        # Convert it to a string, make it lowercase, and check if it equals "true" to ensure a boolean value.
                        ROLE_BASED     = str(s3_config.get("is_role_based", "false")).lower() == "true"
                        ACCESS_KEY     = s3_config.get("accesskey")
                        SECRET_KEY     = s3_config.get("secretkey")
                        BUCKET_NAME    = s3_config.get("bucket")
                        REGION         = s3_config.get("region")

                elif CSP_NAME and CSP_NAME.lower() in ['local', 'localinfra']:
                    error_flag = True
                    s3_config_error_msg = "Samba Server is not included"

                else:
                    botBase.log_writing("Invalid CSP_NAME or missing required config sections", "ERROR")             
                    error_flag = True
                    s3_config_error_msg = "Invalid CSP_NAME or missing required config sections"

                print('queueDetails::', queueDetails)

                        
            except Exception as e:
                botBase.log_writing("ERROR in botBase.readQueueInfo::"+str(e), "ERROR")

        
        botBase.log_writing("---------------", "INFO")
        botBase.log_writing("-------queueDetails--------"+queueDetails['input_queue'], "INFO")
        
        inputJsondata = ''
        if queueDetails is not None and 'input_queue' in queueDetails and queueDetails['input_queue']:
        
            count =int(MessageCount)
            port = 31613 ### this variable is not using in code
            client = "Consumer"

            time_up = False
            Inputlist =[]
            
            while True:

                print("------------------------still True-------------------------------")
                Inputlist, message_id, conn = botBase.connect_and_read_messages(queueDetails['activemq_ip'], client, queueDetails['input_queue'],count)
                print(message_id) #updated on 11.11.2025 by Gowri
                botBase.log_writing(f"Message-ID received: {message_id}", "INFO")

                print('Input message length:: ', len(Inputlist))	
                #sleep_time = random.uniform(1, 3)	

                if len(Inputlist)>0:
                    #inputJsondata = Inputlist[0]

                    #updated on 11.11.2025 by Gowri
                    for i, inputJsondata in enumerate(Inputlist):
                        
                        print(message_id) #updated on 11.11.2025 by Gowri
                        print('Input message length:: ', len(Inputlist))
                        sleep_time = random.uniform(1, 3)	

                        #messageid = message_id[i]  # get matching message-id
                        messageid = message_id[0]
                        print(f"Processing message ID {messageid}")
                        botBase.log_writing(f"Processing message ID {messageid}", "INFO")

                        b_start_time = datetime.now()
                        bot_start_time = re.sub('\.[^<]*?$', '', str(b_start_time))					
                        validation_flag, inputJson_data, input_dict = botBase.validate_input_json(inputJsondata)
                        inputs_dict = json.loads(inputJsondata)
                        REF_ID = inputs_dict["bot_input"][0]["ref_id"]
                        INPUTID = input_dict['InputId']
                        OUTPUTID = input_dict['OutputId']
                        MOBID = input_dict['mobid']
                        CLIENTID = input_dict['clientid']
                        REF_ID = input_dict['ref_id']
                        IN_ID = input_dict['in_id']
                        URL = input_dict['url']
                        NEW_FULPATH = input_dict['new_fullpath']
                        NEW_FILENAME = input_dict['new_filename']
                        NEW_FOLDERNAME = input_dict['new_foldername']
                        HASHCODE = input_dict['hashcode']
                        NEW_SIGNEDS3URL = input_dict['new_signeds3url']
                        OLD_FULLPATH = input_dict['old_fullpath']
                        OLD_FILENAME = input_dict['old_filename']
                        OLD_FOLDERPATH = input_dict['old_folderpath']
                        OLD_SIGNEDS3URL = input_dict['old_signeds3url']
                        REDIRECTED_URL = input_dict['redirected_url']
                        MD5_HASHCODE_REDIRECTEDURL = input_dict['md5_hashcode_redirectedurl']
                        NEW_WEBSITE_STATUS = input_dict['new_website_status']
                        PROJECT_NAME = input_dict['project_name']
                        OLD_WEBSITE_STATUS = input_dict['old_website_status']
                        OLD_PAGE_DATE = input_dict['old_page_date']
                        INPUT_COMPARISON_DATE = input_dict['input_comparison_date']
                        
                        html_comparator = HTMLComparator(NEW_FULPATH, OLD_FULLPATH,BUCKET_NAME)
                    

                        if error_flag:
                            botBase.log_writing(s3_config_error_msg, "ERROR")
                            botBase.output_writer_error(s3_config_error_msg, "1002", bot_start_time, input_dict, PID, inputJsondata, '', messageid, conn)
                            break 
                        
                        
                        tat = ''
                        try:
                            tat = inputs_dict["average_threshold_timeper_inputinsecs"]
                        except:
                            pass
                        
                        if tat=='' or tat==None:
                            tat = queueDetails['average_threshold_timeper_inputinsecs']
                        print("+++++++++tat++++++++++++",tat)
                        print("+++++++++REF_ID",REF_ID)

                        ### COMMENTED BY SASI
                        botBase.log_writing(f"INITIATED::{inputs_dict}", "INFO")
                        # botBase.log_writing(f"INITIATED REF_ID::{REF_ID}", "INFO")
                        botBase.log_writing(f"INITIATED REF_ID::{REF_ID}:::pid::{PID}", "INFO")
                        
                                
                        job_id = REF_ID.split("_")[1]
                        
                        print('job_id:::::',job_id)
                        botBase.log_writing(f"job_id::{job_id}", "INFO") 

                        try:
                            
                            global op_write_flag
                            op_write_flag = 0 
                            
                            global Output_Write_Flag
                            Output_Write_Flag=False
                            
                            global tat_exceed_flag
                            tat_exceed_flag=False

                            global op_queue_push
                            op_queue_push=False
                            
                            
                            t1 = threading.Thread(target=html_comparator.wcm_html_text_compare, daemon=True)
                            t1.start()
                            t1.join(timeout=float(tat))  # Wait for 2 seconds for the process to finish

                            if t1.is_alive():
                                tat_exceed_flag = True
                                
                                print("Process took longer than expected.")
                                botBase.log_writing('TAT Exceeds-error_code:10002', 'INFO')
                                botBase.log_writing('Process took longer than expected. Terminating...', 'INFO')							
                                
                                if Output_Write_Flag == False:
                                    botBase.output_writer_error('TAT Exceeds', "10002", bot_start_time,
                                                            input_dict, PID, inputJsondata, '', messageid, conn)
                                    op_write_flag = 1

                                op_queue_push=True
                                
                                # Choose a random sleep time between 5 and 10 seconds
                                sleep_time = random.uniform(5, 10)

                                print(f"Sleeping for {sleep_time:.2f} seconds.")

                                # Sleep for the chosen duration
                                time.sleep(sleep_time)

                            else:
                                print("else case.............")
                                botBase.log_writing('else case.............' , 'INFO')
                                time.sleep(1)
                                botBase.log_writing('main2::: Output_Write_Flag flag:  ' + str(Output_Write_Flag),"INFO")
                                if op_queue_push==False:
                                    botBase.output_writer_error('Something Went Wrong', "9999", bot_start_time,
                                            input_dict, PID, inputJsondata, '', messageid, conn)
                                    op_queue_push=True

                            if messageid in message_id:
                                message_id.remove(messageid)
                                print("removed message id::",messageid)
                                # if Inputlist:
                                #     Inputlist.clear()

                            print("message_id list finally :::::", message_id)
                            print("input list finally", len(Inputlist))

                            if not message_id  and conn.is_connected():
                                conn.disconnect()
                                print("Queue connection disconnected in main as there is no messages")
                                botBase.log_writing("Queue connection disconnected in main as there is no messages", "INFO")
                                    
                        except Exception as h:
                            botBase.log_writing('Error in main: error_code:1001' + str(h), 'ERROR')
                            botBase.output_writer_error('Error in main:' + str(h), "1001", bot_start_time,
                                                                        input_dict, PID, inputJsondata, '', messageid, conn)
                            op_queue_push=True
                            
                        finally:
                            print("finally")
                            botBase.cleanup_memory()

                            # Check MQ disconnect flag
                            if mq_is_disconnected():
                                print("MQ DISCONNECTED — continuing loop without sleeping")
                                botBase.log_writing("MQ DISCONNECTED — continuing loop", "INFO")
                                time.sleep(2)
                                continue  # restart while True immediately

                            sleep_time = random.uniform(1, 3)
                            

                else:
                    print('----------push_json_to_statuesqueue-------------')
                    botBase.push_json_to_statuesqueue(queueDetails,status='UNUSED')
                    sys.exit(0)	
    
    except Exception as main_error:
        print(f'An error occurred in the main function: {main_error}')
    finally:
        botBase.log_writing('Script Completed!!!', 'INFO')
        print('Script Completed!!!')
        if conn and conn.is_connected():
            conn.disconnect()
            print("connection  disconnected in finally")
            botBase.log_writing('connection  disconnected in finally', 'INFO')
        else:
            print("connection already disconnected")
            botBase.log_writing("connection already disconnected", 'INFO')
        botBase.infinite_sleep()
        #sys.exit(0)	
        
sys.exit(0)	 