# updated "send_msg_initiated" function on 25-09-2024
# updated supports running both ActiveMQ and AmazonMQ based on queue.json details. on 11-02-2025
# inserted "copy_inputJsonKeyValues_to_outputjson" function on 15-02-2025 which Merges input_dict with each dictionary
# in output_list.
# Assigned the variable "input_output_merged" to the ""output_format['Result']['Output']"" - 15-02-2025
# Updated "connect_and_read_messages" and "connect_and_push_messages" functions with RETRY part --
# 24-02-2025 By Vinitha S
# If the ActiveMQ or AmazonMQ connection fails, the functions will attempt to reconnect up to three times before failing
# updated acknowledgement method - disconnected before return on 19-03-2025 (updated by Vignesh)
# Updated rename for new connection and removed unwanted function on 21-03-2025
# Updated acknowledgement method -  Attempts to acknowledge a message in ActiveMQ. If the connection is lost,
# it will retry up to max_retries times. A new connection is established, but the message is not acknowledged while the
# output is still pushed.  on 24-03-2024
# bot_base_Version : 3.0 and added it to the log
# Updated the SSL error capture and, in the case of connect_and_push_messages failed no acknowledgement(input),
# set a flag. on 04-04-2025
# Bot base version updated from 3.0 to 3.1
# Updated the "push_json_to_statuesqueue" method to capture SSL errors and implement retry handling on 07-04-202.
# Bot base version updated from 3.1 to 3.2
# Bot base version updated from 3.2 to 3.3
# Included Samba Upload, Samba download, S3 Role based, S3 Key based function in version 3.3- Added by Bhuvana 09-04-25
# Another SSLError expection handling for connect_and_push_messages and push_json_to_statuesqueue version 3.3 - Added by Yoga lakshmi S 10-4-25

#22-04-2025 - Extra SSL Error handling Added by Yoga lakshmi S (I didn't change the version because this is only for testing purposes.)
#25-04-2025 - explicit exceptions handled for S3 and SMB functions by Bhuvana in version 3.3 and now the version is 3.4

# Using single connection for input queue, output queue, acknowledgement  . version - 3.5_RCA_Single_Connection
# 26-11-2025 handled conn lost scenario at connect and push method . version - 3.6_RCA_Single_Connection
# 27-11-2025 getting public ip method changed  in get_processed_ip function due to threading issue . version - 3.7_RCA_Single_Connection
# 02-12-2025 Implemented retry count increment in exceptions in push_json_to_statuesqueue function . version -  3.8_RCA_Single_Connection
# 03-12-2025 Commented print statement of final output . version -  3.9_RCA_Single_Connection
# 16-12- 2025 No changes, only version name changed - 3.9_Single_Connection_XDAS_Prod

import os
import re
import io
import ssl
import uuid
import sys
import json
import time
import stomp
import boto3
import socket
import random
import logging
import datetime
import requests
import platform
import threading
import smbclient
import subprocess
import public_ip as IP
import psutil, os, gc
from smbclient import open_file, register_session
from stomp.exception import ConnectFailedException, NotConnectedException


class botBase(object):

    def __init__(self, job_id=None, log_path=None, processed_ip=None, activemq_port=None, mq_server_name=None,
                 activemq_username=None, activemq_password=None):

        version = "3.9_Single_Connection_XDAS_Prod"

        self.job_id = job_id
        self.log_path = log_path
        self.processed_ip = processed_ip
        self.activemq_port = activemq_port
        self.mq_server_name = mq_server_name
        self.activemq_username = activemq_username
        self.activemq_password = activemq_password
        self.version = version

        self.mq_host = None
        self.mq_port = None

    def log_writing(self, log_data, log_flag):

        """
        Writes log to a txt file
        """
        local_hostname = socket.gethostname()
        local_ip = socket.gethostbyname(local_hostname)
        container_ip = self.containerIpPatternMatch(local_ip)
        if self.job_id is None:
            queueDetails = botBase.readQueueInfo(self)
            config_json = self.instance_config_json_reader()

            self.log_path = config_json['log_path']
            self.activemq_port = queueDetails.get('activemq_port')

            if queueDetails is not None and queueDetails.get('mq_server_name') is not None:
                self.mq_server_name = queueDetails['mq_server_name']
            if queueDetails is not None and queueDetails.get('activemq_username') is not None:
                self.activemq_username = queueDetails['activemq_username']
            if queueDetails is not None and queueDetails.get('activemq_password') is not None:
                self.activemq_password = queueDetails['activemq_password']
            if queueDetails is not None and queueDetails.get('job_id') is not None:
                self.job_id = queueDetails['job_id']
            if queueDetails is not None and queueDetails.get('csp_id') is not None:
                self.csp_id = int(queueDetails['csp_id'])
                if self.csp_id == 1:
                    self.processed_ip = botBase.retrieving_aws_instance_metadata(self)
                else:
                    self.processed_ip = botBase.retrieving_localinfra_ip(self)
            else:
                self.log_path = str(self.log_path)
                self.processed_ip = str(self.processed_ip)
                container_ip = str(container_ip)
                mounting_log_path = self.log_path + self.processed_ip + '/' + container_ip + '/'

        if self.job_id is not None:
            mounting_log_path = self.log_path + str(self.job_id) + '/' + self.processed_ip + '/' + container_ip + '/'
        else:
            mounting_log_path = self.log_path + self.processed_ip + '/' + container_ip + '/'
        if not os.path.isdir(mounting_log_path):
            os.makedirs(mounting_log_path, exist_ok=True)

        log_file_name = self.processed_ip + "_bot.txt"
        ping_log_fileName = os.path.join(mounting_log_path, log_file_name)
        logging.basicConfig(filename=ping_log_fileName, level=logging.INFO,
                            format="%(asctime)s\t%(levelname)s\t%(message)s")
        log_header = ''.encode("utf-8")
        open(ping_log_fileName, 'ab').write(log_header)
        if log_flag == 'INFO':
            logging.info(log_data)
        elif log_flag == 'ERROR':
            logging.error(log_data)


    input_message_list = []

    def readQueueInfo(self):
        try:
            with open("queueInfo.json", 'r') as file:
                data = json.load(file)

            return data
        except FileNotFoundError:
            print("queueInfo.json File is not found")
            return None
        except json.JSONDecodeError as e:
            print(f"JSON decoding error: {e}")
            return None
        

    def connect_and_read_messages(self, host, client, queue_name, MessageCount):

        class MyListener(stomp.ConnectionListener):
            print('--------1-------')

            def __init__(self, connection, max_messages, message_list, message_id):
                print(f"Initializing MyListener with max_messages: {max_messages}")
                # self.log_writing (" MyListener  method called on bot base  :"+queue_name,"INFO")
                self.conn = connection
                self.max_messages = max_messages
                self.messages_received = 0
                self.input_message_list = message_list
                self.message_id_input = message_id
                print(f"Message list initialized: {message_list}")
                print(f"Message ID list initialized: {message_id}")

            def on_message(self, frame):
                print("Received message from queue")
                self.message_id_input.append(frame.headers.get('message-id'))
                # if frame.headers.get('message-id') is None:
                # self.Messagecount=0
                print("Before Acknowledgment - Messages Received:", self.messages_received)
                # self.conn.ack(frame.headers.get('message-id'), 1)
                body = frame.body
                self.input_message_list.append(body)
                self.messages_received += 1

            # def on_disconnected(self):
            #     print("ActiveMQ CONNECTION LOST!!")

            #     # Write DISCONNECTED flag
            #     with open("mq_status_flag", "w") as f:
            #         f.write("DISCONNECTED")

        print("Inside connect and read message method")
        self.log_writing("Inside connect_and_read_messages method", "INFO")

        message_id_input = []
        input_message_list = []  # Create an empty list
        message_count_lock = threading.Lock()

        retry_attempts = 3  # Number of retry attempts for connection failure
        attempt = 0

        while attempt < retry_attempts:
            try:
                # Define SSL options
                # ssl_opts = {'ssl_version': ssl.PROTOCOL_TLSv1_2,'cert_reqs': ssl.CERT_NONE)  # Use TLS v1.2
                # 'ca_certs': '/path/to/ca_certificate.pem',  # Optional: Specify CA certificate if required
                # 'cert_file': '/path/to/client_certificate.pem',  # Optional: Client certificate
                # 'key_file': '/path/to/client_key.pem',  # Optional: Client key
                # WARNING: Disables certificate verification (not recommended for production)
                # conn.set_ssl(for_hosts=[(host, '61614')], ssl_version=ssl.PROTOCOL_TLS)
                # ssl_context=ssl.create_default_context()
                # ssl_context.check_hostname = True
                # ssl_context.verify_mode = ssl.CERT_REQUIRED
                # conn = stomp.Connection12(host_and_ports=[(host,'61614')],heartbeats=(4000,4000),
                # ssl_context=ssl_context)
                # conn.set_ssl(for_hosts=[(host, '61614')], ssl_version=ssl.PROTOCOL_TLS)
                # conn = stomp.Connection(host_and_ports=[(host, '61617')], use_ssl=True)

                self.log_writing(f"Bot_Base Version::{self.version}", "INFO")

                queueDetails = botBase.readQueueInfo(self)
                mq_server_name = queueDetails.get('mq_server_name')
                print("----mq_Server_name---", mq_server_name)

                #conn = stomp.Connection(host_and_ports=[(host, self.activemq_port)], timeout=600)
                conn = stomp.Connection(host_and_ports=[(host, self.activemq_port)],heartbeats=(1800000, 1800000) ) # 30 minutes heartbeat

                self.conn = conn   # store connection globally for reuse

                if self.mq_server_name and self.mq_server_name.lower() == "amazonmq":

                    print(f"Amazonmq Port ... {self.activemq_port}")
                    self.log_writing(f"Amazonmq Port ... {self.activemq_port}", "INFO")

                    print("Running under Amazonmq...")
                    self.log_writing("Running under Amazonmq...", "INFO")
                    conn.set_ssl(for_hosts=[(host, self.activemq_port)], ssl_version=ssl.PROTOCOL_TLSv1_2)

                    my_listener = MyListener(connection=conn, max_messages=MessageCount,
                                             message_list=input_message_list, message_id=message_id_input)
                    conn.set_listener('', my_listener)

                    self.log_writing(
                        " queue connection establishing and connect and read  messages on bot base  :" + queue_name,
                        "INFO")
                    conn.connect(self.activemq_username, self.activemq_password, wait=True)
                    self.log_writing(
                        " queue connection established and connect and read  messages on bot base  :" + queue_name,
                        "INFO")

                    conn.subscribe(destination=f'/queue/{queue_name}', id=1, ack='client-individual',
                                   headers={'activemq.prefetchSize': MessageCount})

                elif self.mq_server_name and self.mq_server_name.lower() == "activemq":

                    print("Running under Activemq....")
                    self.log_writing("Running under Activemq...", "INFO")

                    client = uuid.uuid4()
                    print("Connect and read message client ID:::",client)
                    self.log_writing(f"Connect and read message client ID: {client}", "INFO")

                    my_listener = MyListener(connection=conn, max_messages=MessageCount,
                                             message_list=input_message_list, message_id=message_id_input)
                    conn.set_listener('', my_listener)

                    username = queueDetails.get('activemq_username')  # Your ActiveMQ username (if applicable)
                    password = queueDetails.get('activemq_password')
                    activemq_port = queueDetails.get('activemq_port')
                    print(f"Activemq Port... {activemq_port}")
                    self.log_writing(f"Activemq Port...  {activemq_port}", "INFO")
                    self.log_writing(
                        " queue connection establishing and connect and read  messages on bot base  :" + queue_name,
                        "INFO")
                    conn.connect(username, password,headers={'client': client}, wait=True) #added client id (uuid) in headers
                    self.log_writing(
                        " queue connection established and connect and read  messages on bot base  :" + queue_name,
                        "INFO")
                    conn.subscribe(destination=f'/queue/{queue_name}', id=1, ack='client-individual',
                                   headers={'activemq.prefetchSize': MessageCount})
                else:
                    print("Other...")
                    self.log_writing("Other...", "INFO")
                    sys.exit(0)

                retrycount = 0

                while True:

                    with message_count_lock:
                        if len(my_listener.input_message_list) >= MessageCount:
                            print(f"Retrying message fetch, count: {retrycount}")
                            self.log_writing(f"Retrying message fetch, count: {retrycount}", "INFO")
                            self.log_writing("retry method called on bot base  :" + queue_name, "INFO")
                            break

                        retrycount += 1

                        if retrycount > 5:
                            MessageCount = 0
                        time.sleep(1)

                # Disconnect from ActiveMQ

                print(f"total message received -----  {my_listener.messages_received}")
                print(f"total message acknowledged----------- {len(message_id_input[0])}")

                connection_id = hex(id(conn))
                remote_address = ""
                remote_info = conn.transport.current_host_and_port
                if remote_info and isinstance(remote_info, tuple):
                    remote_address = f"{remote_info[0]}:{remote_info[1]}"

                self.log_writing(f"connection for connect_and_read_messages : {conn}", "INFO")
                self.log_writing(f"conn remote_address : {remote_address}", "INFO")
                self.log_writing(f"Connection ID: {connection_id}", "INFO")


                return input_message_list, message_id_input, conn

            except stomp.exception.ConnectFailedException as e:

                print(f"Connection to {self.mq_server_name} with port {self.activemq_port} Failed , "
                      f"So initiating Retries...")
                self.log_writing(f"Connection to {self.mq_server_name} with port {self.activemq_port} Failed , "
                                 f"So initiating Retries....", "INFO")
                attempt += 1

                print(f"CONNECTION TO  '{self.mq_server_name}' FAILED: {str(e)}")
                self.log_writing(f"CONNECTION TO '{self.mq_server_name}' FAILED: {str(e)}", "ERROR")
                print(":::::::::::::::::::::::RETRYING:::::::::::::::")
                self.log_writing(":::::::::::::::::::::::RETRYING:::::::::::::::", "INFO")
                print(f"Connection attempt {attempt} failed: {str(e)}")
                self.log_writing(f"Connection attempt {attempt} failed - case1::{str(e)}", "ERROR")

                sleep_time = random.randint(5, 15)
                self.log_writing(f"Sleeping for {sleep_time} secs...", "INFO")
                time.sleep(sleep_time)

                if attempt == retry_attempts:
                    print("++++++++++++++ Maximum retry reached +++++++++++++")
                    self.log_writing("+++++++++++++++ Maximum retry reached +++++++++++", "ERROR")
                    # self.send_failure_activemq_status(queueDetails='', status='ACTIVEMQ_FAILED')

                    self.log_writing(f"{self.mq_server_name}_FAILED", "INFO")
                    self.log_writing("Script terminating!!!!", "INFO")
                    print("Script terminating !!!!")
                    sys.exit(0)

                time.sleep(2)  # Wait before retrying

            except Exception as e:

                print(f"Exception occurred: {type(e).__name__} - {e}")
                self.log_writing(f"Exception in connect_and_read_messages: {type(e).__name__} - {e}", "INFO")
                self.log_writing("No message in queue::", "INFO")
                break

        connection_id = hex(id(conn))
        remote_address = ""
        remote_info = conn.transport.current_host_and_port
        if remote_info and isinstance(remote_info, tuple):
            remote_address = f"{remote_info[0]}:{remote_info[1]}"

        self.log_writing(f"connection for connect_and_read_messages : {conn}", "INFO")
        self.log_writing(f"conn remote_address : {remote_address}", "INFO")
        self.log_writing(f"Connection ID: {connection_id}", "INFO")

        return input_message_list, message_id_input, conn
    
    
    def memory_cleanup_if_needed(self, threshold_mb=900):
        try:
            process = psutil.Process(os.getpid())
            mem_used = process.memory_info().rss / (1024 * 1024)

            if mem_used > threshold_mb:   # cleanup only when usage exceeds threshold
                print(f"[Memory] High usage detected: {mem_used:.2f} MB. Running GC...")
                self.log_writing(
                    f"[Memory] High usage detected: {mem_used:.2f} MB. Running GC...",
                    "INFO"
                )
                gc.collect()
                mem_after = process.memory_info().rss / (1024 * 1024)
                print(f"[Memory] After GC: {mem_after:.2f} MB")
                self.log_writing(
                    f"Memory cleanup triggered: Before={mem_used:.2f}MB After={mem_after:.2f}MB",
                    "INFO"
                )

        except Exception as e:
            print(f"Error in memory_cleanup_if_needed : {str(e)}")
            self.log_writing(f"Error in memory_cleanup_if_needed : {str(e)}","ERROR")


    def acknowledgement(self, host, messageack, conn, max_retries=5):

        print("inside acknowledgement")
        self.log_writing("inside acknowledgement", "INFO")
        retries = 0

        while retries < max_retries:
            try:
                
                # ✅ use self.conn globally (set earlier in connect_and_read_messages)
                self.conn.ack(messageack, 1)
                print("Acknowledging message id-----> ",messageack)
                #conn.ack(messageack, 1)
                print("Acknowledged")
                self.log_writing("Acknowledged", "INFO")

                # Cleanup memory ONLY if too high
                self.memory_cleanup_if_needed(threshold_mb=900)

                sleep_time = random.randint(5,15)  # Random sleep even after success
                time.sleep(sleep_time)
                #conn.disconnect()
                #self.conn.disconnect()
                return  # Exit if successful

            except Exception as e:
                print("acknowledgement expection case...")
                self.log_writing(f"acknowledgement expection case...", "ERROR")

                if self.mq_server_name.lower() == "amazonmq":
                    if not conn.is_connected():
                        print(f"Exception occurred during acknowledgement: {e}")
                        print(f"Retrying AmazonMQ connection (Attempt {retries}/{max_retries})...")
                        self.log_writing(f"Retrying AmazonMQ connection (Attempt {retries})...", "WARNING")
                        conn_ack = stomp.Connection(host_and_ports=[(host, self.activemq_port)])
                        conn_ack.set_ssl(for_hosts=[(host, self.activemq_port)], ssl_version=ssl.PROTOCOL_TLSv1_2)
                        conn_ack.connect(self.activemq_username, self.activemq_password, wait=True)

                        try:
                            conn_ack.ack(messageack, 1)
                            sleep_time = random.randint(5, 15)
                            time.sleep(sleep_time)
                            conn_ack.disconnect()
                            print("AmazonMQ acknowledgement successful.")
                            return  # Exit if successful
                        except Exception as s:
                            print(f"AmazonMQ acknowledgement failure while retrying {s}")
                            self.log_writing(f"AmazonMQ acknowledgement failure while retrying {s}", "ERROR")

                elif self.mq_server_name.lower() == "activemq":

                    #if not conn.is_connected():
                    if not self.conn or not self.conn.is_connected() :

                        print("------------ACTIVE MQ--------")
                        print(f"Retrying ActiveMQ connection (Attempt {retries}/{max_retries})...")
                        self.log_writing(f"Retrying ActiveMQ connection (Attempt {retries})...", "WARNING")
                        conn_activemq = stomp.Connection(host_and_ports=[(host, self.activemq_port)])
                        conn_activemq.connect(self.activemq_username, self.activemq_password, wait=True)

                        try:
                            conn_activemq.ack(messageack, 1)
                            print("----Activemq ack----")
                            sleep_time = random.randint(5, 15)
                            time.sleep(sleep_time)
                            conn_activemq.disconnect()
                            print("ActiveMQ acknowledgement successful.")
                            return  # Exit if successful

                        except Exception as s:
                            print(f"ActiveMQ acknowledgement failure while retrying {s}")
                            self.log_writing(f"ActiveMQ acknowledgement failure while retrying {s}", "ERROR")
                    else:
                        self.log_writing("Connection still active. Retrying ack...", "INFO")

                retries += 1

        print("acknowledgement Max retries reached, disconnecting...")
        self.log_writing("acknowledgement Max retries reached, disconnecting...", "ERROR")
    

    def write_mq_status(self, status: str) -> None:
        """Write MQ connection status to a local file."""
        try:
            with open("mq_status_flag.txt", "w") as f:
                f.write(status)
                f.flush()  # ensures content is written immediately
        except Exception as e:
            error_msg = f"Error in write_mq_status: {e}"
            print(error_msg)
            self.log_writing(error_msg, "ERROR")


    def connect_and_push_messages(self, host, queue_name, mainDict_n):

        try:

            print("Starting connect_and_push_messages function")

            json_data = json.dumps(json.loads(mainDict_n), indent=None)
            main_dict = json.loads(mainDict_n)
            properties = {
                "processed_ip": main_dict['Processed_IP'],
                "bot_initiated_time": main_dict['bot_start_time'],
                "bot_result_time": main_dict['bot_end_time'],
                "RefID": main_dict['ref_id']
            }

            queueDetails = botBase.readQueueInfo(self)
            self.mq_server_name = queueDetails.get('mq_server_name')  # Ensure it's set before retry loop
            print("----mq_Server_name---", self.mq_server_name)

            retry_count = 0
            max_retries = 3

            while retry_count < max_retries:
            
                try:
                    print(f"Attempt {retry_count + 1} to connect")

                    #conn_op = stomp.Connection([(host, self.activemq_port)])

                    if self.mq_server_name and self.mq_server_name.lower() == "amazonmq":
                        conn_op = stomp.Connection([(host, self.activemq_port)]) # added by gowri, since testing changes are done only for ActiveMQ
                        print(f"amazonmq_port... {self.activemq_port}")
                        self.log_writing(f"amazonmq_port... {self.activemq_port}", "INFO")

                        conn_op.set_ssl(for_hosts=[(host, self.activemq_port)], ssl_version=ssl.PROTOCOL_TLSv1_2)

                        # Add a wait=True in the connect() method to ensure the connection is fully established before
                        # sending messages. (24.02.2025)
                        conn_op.connect(self.activemq_username, self.activemq_password, wait=True)
                        print("Connection established")
                        self.log_writing(" queue connection established and sending messages on bot base in connect and "
                                         "push message method :" + queue_name, "INFO")

                        try:
                            self.log_writing("Inside conn.send of try except", "INFO")
                            # conn.start()  # Ensure connection is properly started
                            properties["persistent"] = "true"  # Ensure message is persistent
                            conn_op.send(body=json_data, destination=queue_name, headers=properties)
                            is_push_successful = True
                            # conn.disconnect()
                        
                        except ssl.SSLError as ssl_err:
                            
                            error_msg = str(ssl_err)
                            
                            if "missing fatal" in error_msg.lower():
                                self.log_writing(
                                    "SSL error [MISSING_FATAL] while sending message in connect_and_push_messages: " + error_msg,
                                    "ERROR")
                                print("SSL error [MISSING_FATAL]:", error_msg)

                            elif "record layer failure" in error_msg.lower():
                                self.log_writing(
                                    "SSL error [RECORD_LAYER_FAILURE] in connect_and_push_messages: " + error_msg,
                                    "ERROR")
                                print("SSL error [RECORD_LAYER_FAILURE]:", error_msg)

                            else:
                                self.log_writing(
                                    "SSL error while sending message in connect_and_push_messages (SSLError): " + error_msg,
                                    "ERROR")
                                print("SSL error while sending message in connect_and_push_messages (SSLError): ", error_msg)
                                
                            is_push_successful = False
                            return is_push_successful
                            
                        except ssl.SSLEOFError as e:
                        
                            self.log_writing("SSL EOF error while sending message in connect_and_push_messages "
                                             "Function: " + str(e), "ERROR")
                            print("SSL EOF error while sending message in connect_and_push_messages Function: ",
                            str(e))
                            
                            is_push_successful = False
                            return is_push_successful

                        except json.JSONDecodeError as e:
                        
                            self.log_writing(f"JSON parsing error: {str(e)}", "ERROR")
                            print(f"JSON parsing error: {str(e)}")
                            
                            is_push_successful = False
                            return is_push_successful

                        except stomp.exception.ConnectFailedException as e:
                        
                            self.log_writing(f"STOMP Connection error: {str(e)}", "ERROR")
                            print(f"STOMP Connection error: {str(e)}")
                            
                            is_push_successful = False
                            return is_push_successful

                        except Exception as e:
                        
                            self.log_writing(f"Error sending data to queue: {str(e)}", "ERROR")
                            print(f"Error sending data to queue: {str(e)}")
                            
                            is_push_successful = False
                            return is_push_successful

                        conn_op.disconnect()

                        print("Connection disconnected successfully")
                        self.log_writing("output queue connection disconnected on Botbase on connect and push method :"
                                         + queue_name, "INFO")
                        # return  # Ensure function exits after success
                        return is_push_successful

                    elif self.mq_server_name and self.mq_server_name.lower() == "activemq":
                    
                        print(f"activemq_port... {self.activemq_port}")
                        self.log_writing(f"activemq_port... {self.activemq_port}", "INFO")

                        # conn_op = stomp.Connection([(host, self.activemq_port)])
                        # conn_op.connect()
                        # print("Connection established")
                        # self.log_writing("queue connection established and sending messages on bot base in connect and "
                        #                     "push message method :" + queue_name, "INFO")
                        

                        if not self.conn or not self.conn.is_connected():
                            print("Connection lost in connect_and_push_messages")
                            self.log_writing("Connection lost in connect_and_push_messages", "ERROR")
                            print("MQ connection not active. Creating DISCONNECTED flag.")
                            self.write_mq_status("DISCONNECTED")
                            is_push_successful = False

                        else:
                            print("Connection available in connect_and_push_messages ")
                            self.log_writing("queue connection available and sending messages on bot base in connect and "
                                            "push message method :" + queue_name, "INFO")
                            #conn_op.send(body=json_data, destination=queue_name, headers=properties)
                            self.conn.send(body=json_data, destination=queue_name, headers=properties)
                            print(f"Sending message to queue: {queue_name}")
                            self. write_mq_status("CONNECTED")
                            is_push_successful = True
                        #conn_op.disconnect()

                        # print("Connection disconnected successfully")
                        # self.log_writing("output queue connection disconnected on Botbase on connect and push method :"
                        #                  + queue_name, "INFO")
                        # return  # Ensure function exits after success
                        return is_push_successful

                    else:
                        print("Other 1...")
                        self.log_writing("Other...", "INFO")
                        sys.exit(0)

                except NotConnectedException as e:  # amazon mq connection failed exception
                    print(f"Connection to {self.mq_server_name} with port {self.activemq_port} Failed , "
                          f"So initiating Retries")
                    self.log_writing(f"Connection to {self.mq_server_name} with port {self.activemq_port} Failed , "
                                     f"So initiating Retries !!", "INFO")
                    retry_count += 1
                    print(f"Retry {retry_count}/{max_retries} failed: {str(e)}")
                    self.log_writing(f"Connection failed, retrying {retry_count}/{max_retries}. Exception: {str(e)}",
                                     "ERROR")

                    sleep_time = random.randint(5, 15)
                    self.log_writing(f"Sleeping for {sleep_time} secs...", "INFO")
                    time.sleep(sleep_time)

                    if retry_count == max_retries:
                        print("Maximum retry reached")
                        self.log_writing("Maximum retry reached", "ERROR")

                        print(
                            f"Connection to {self.mq_server_name} with port {self.activemq_port} Failed After 3 retries")
                        self.log_writing(
                            f"Connection to {self.mq_server_name} with port {self.activemq_port} Failed After 3 retries",
                            "INFO")
                        print("Script terminating after max retry attempts!")
                        self.log_writing("Script terminating after max retry attempts!", "INFO")
                        # self.send_failure_activemq_status(queueDetails='', status='ACTIVEMQ_FAILED')
                        self.log_writing(f"{self.mq_server_name}_FAILED", "INFO")
                        self.log_writing("Script terminating!!!!", "INFO")
                        print("Script terminating !!!!")
                        sys.exit(0)

                    time.sleep(2)

                except ConnectFailedException as e:  # active mq connection failed exception
                    print(f"Connection to {self.mq_server_name} with port {self.activemq_port} Failed, "
                          f"So initiating Retries")
                    self.log_writing(f"Connection to {self.mq_server_name} with port {self.activemq_port} Failed, "
                                     f"So initiating Retries !!", "INFO")
                    retry_count += 1
                    print(f"Retry {retry_count}/{max_retries} failed: {str(e)}")
                    self.log_writing(f"Connection failed, retrying {retry_count}/{max_retries}. Exception: {str(e)}",
                                     "ERROR")

                    sleep_time = random.randint(5, 15)
                    self.log_writing(f"Sleeping for {sleep_time} secs...", "INFO")
                    time.sleep(sleep_time)

                    if retry_count == max_retries:
                        print("Maximum retry reached")
                        self.log_writing("Maximum retry reached", "ERROR")

                        print(f"Connection to {self.mq_server_name} with port {self.activemq_port} "
                              f"Failed After 3 retries")
                        self.log_writing(f"Connection to {self.mq_server_name} with port {self.activemq_port} "
                                         f"Failed After 3 retries", "INFO")

                        print("Script terminating after max retry attempts!")
                        self.log_writing("Script terminating after max retry attempts!", "INFO")

                        self.log_writing("Script terminating........", "INFO")
                        print("Script terminating........")
                    time.sleep(2)

        except Exception as e:
            exception_type = type(e).__name__
            print("exception_type:::", exception_type)
            print(f"Exception occurred: {e}")
            self.log_writing("To send data outputqueue Exception is " + str(e), "ERROR")

        finally:
            print("Exiting connect_and_push_messages function-Finally block")
            self.log_writing("Exiting connect_and_push_messages function-Finally block", "INFO")

        # return is_push_successful

    def push_json_to_statuesqueue(self, queueDetails, status):

        try:
            retry_count = 0
            max_retries = 3

            while retry_count < max_retries:
                try:
                    self.log_writing("status  queue method called", "INFO")
                    local_hostname = socket.gethostname()
                    local_ip = socket.gethostbyname(local_hostname)

                    self.log_writing("Calling bot base status queue unused messages", "INFO")
                    csp_id = int(queueDetails['csp_id'])

                    if csp_id == 1:
                        processed_ip = botBase.retrieving_aws_instance_metadata(self)
                    else:
                        processed_ip = botBase.retrieving_localinfra_ip(self)

                    json_data = {
                        "container_ip": botBase.containerIpPatternMatch(self, local_ip),
                        "processed_ip": processed_ip,
                        "ack_message_count": "",
                        "bot_name": "",
                        "bot_status": "UNUSED",
                        "user_id": "",
                        "job_id": queueDetails['job_id'],
                        "is_always_on": queueDetails['is_always_on'],
                        "max_replicas_per_vm": queueDetails.get('max_replicas_per_vm', ''),
                        "bot_id": "",
                        "csp_id": queueDetails['csp_id']
                    }

                    host = queueDetails['activemq_ip']
                    username = queueDetails['activemq_username']
                    password = queueDetails['activemq_password']

                    self.log_writing("JSON data ....." + str(json_data), "INFO")

                    queueDetails = botBase.readQueueInfo(self)
                    mq_server_name = queueDetails.get('mq_server_name')
                    print("----mq_Server_name---", mq_server_name)

                    print(f"Attempt {retry_count + 1} to connect")
                    #conn_sq = stomp.Connection([(host, self.activemq_port)])

                    queue_name = queueDetails['status_queue']

                    try:
                        if self.mq_server_name and self.mq_server_name.lower() == "amazonmq":
                            conn_sq = stomp.Connection([(host, self.activemq_port)])
                            conn_sq.set_ssl(for_hosts=[(host, self.activemq_port)], ssl_version=ssl.PROTOCOL_TLSv1_2)
                            conn_sq.connect(username, password)
                            time.sleep(1)
                            conn_sq.send(body=json.dumps(json_data), destination=queue_name)
                            logging.info("Queue connection established and message sent to status queue: " + queue_name)
                            conn_sq.disconnect()
                            logging.info("Queue connection disconnected after sending message: " + queue_name)
                            print("JSON data sent successfully.")
                            return

                        elif self.mq_server_name and self.mq_server_name.lower() == "activemq":

                            if not self.conn or not self.conn.is_connected():
                                print("Connection lost while pushing json to statuesqueue")
                                self.log_writing("Connection lost while pushing json to statuesqueue", "ERROR")
                                # Recreate connection
                                conn_sq = stomp.Connection([(host, self.activemq_port)])
                                conn_sq.connect()
                                print(" New connection established in push_json_to_statuesqueue method")
                                self.log_writing(" New queue connection established and sending messages on bot base in push_json_to_statuesqueue ", "INFO")
                                conn_sq.send(body=json.dumps(json_data), destination=queue_name)
                                conn_sq.disconnect()
                                self.log_writing("Queue connection disconnected after sending message: " + queue_name,"INFO")
                                print("JSON data sent successfully.")

                                return
                               
                            else:  
                                #conn_sq.connect()
                                time.sleep(1)
                                #conn_sq.send(body=json.dumps(json_data), destination=queue_name)
                                self.conn.send(body=json.dumps(json_data), destination=queue_name)
                                self.log_writing("Queue connection available and message sent to status queue: " + queue_name,"INFO")
                                #conn_sq.disconnect()
                                self.conn.disconnect()
                                self.log_writing("Queue connection disconnected after sending message: " + queue_name,"INFO")
                                print("JSON data sent successfully.")
                                return

                        else:
                            print("Other 2...")
                            self.log_writing("Other...", "INFO")
                            os._exit(0)
                    
                    except ssl.SSLError as ssl_err:
                        
                        error_msg = str(ssl_err)
                            
                        if "missing fatal" in error_msg.lower():
                            self.log_writing(
                                "SSL error [MISSING_FATAL] while sending message in push_json_to_statuesqueue: " + error_msg,
                                "ERROR")
                            print("SSL error [MISSING_FATAL]:", error_msg)

                        elif "record layer failure" in error_msg.lower():
                            self.log_writing(
                                "SSL error [RECORD_LAYER_FAILURE] in push_json_to_statuesqueue: " + error_msg,
                                "ERROR")
                            print("SSL error [RECORD_LAYER_FAILURE]:", error_msg)

                        else:
                            self.log_writing(
                                "SSL error while sending message in push_json_to_statuesqueue (SSLError): " + error_msg,
                                "ERROR")
                            print("SSL error while sending message in push_json_to_statuesqueue (SSLError): ", error_msg)

                        retry_count += 1
                        print(f"Retry {retry_count}/{max_retries} failed: {str(e)}")
                        self.log_writing(f"Connection failed, retrying {retry_count}/{max_retries}. Exception: {str(e)}", "ERROR")

                        if retry_count == max_retries:
                            print("Maximum retry reached")
                            self.log_writing("Maximum retry reached", "ERROR")

                            print(f"Connection to {self.mq_server_name} with port {self.activemq_port} Failed After 3 retries")
                            self.log_writing(f"Connection to {self.mq_server_name} with port {self.activemq_port} "
                                            f"Failed After 3 retries", "INFO")
                            print("Script terminating after max retry attempts!")
                            self.log_writing("Script terminating after max retry attempts!", "INFO")
                            # self.send_failure_activemq_status(queueDetails='', status='ACTIVEMQ_FAILED')
                            self.log_writing(f"{self.mq_server_name}_FAILED", "INFO")
                            self.log_writing("Script terminating!!!!", "INFO")
                            print("Script terminating !!!!")
                            os._exit(0)

                        time.sleep(2)

                            
                    except ssl.SSLEOFError as ssl_err:

                        self.log_writing(
                            "SSL EOF error while sending message in push_json_to_statuesqueue(SSLEOFError): " + str(ssl_err),
                            "ERROR")
                        print("SSL EOF error while sending message:", str(ssl_err))

                        retry_count += 1
                        print(f"Retry {retry_count}/{max_retries} failed: {str(e)}")
                        self.log_writing(f"Connection failed, retrying {retry_count}/{max_retries}. Exception: {str(e)}", "ERROR")

                        if retry_count == max_retries:
                            print("Maximum retry reached")
                            self.log_writing("Maximum retry reached", "ERROR")

                            print(f"Connection to {self.mq_server_name} with port {self.activemq_port} Failed After 3 retries")
                            self.log_writing(f"Connection to {self.mq_server_name} with port {self.activemq_port} "
                                            f"Failed After 3 retries", "INFO")
                            print("Script terminating after max retry attempts!")
                            self.log_writing("Script terminating after max retry attempts!", "INFO")
                            # self.send_failure_activemq_status(queueDetails='', status='ACTIVEMQ_FAILED')
                            self.log_writing(f"{self.mq_server_name}_FAILED", "INFO")
                            self.log_writing("Script terminating!!!!", "INFO")
                            print("Script terminating !!!!")
                            #sys.exit(0)
                            os._exit(0)

                        time.sleep(2)


                except Exception as e:
                    
                    logging.error(f"Exception occurred in push_json_to_statuesqueue: {e}")
                    self.log_writing("Exception in push_json_to_statuesqueue: " + str(e), "ERROR")

                    retry_count += 1
                    print(f"Retry {retry_count}/{max_retries} failed: {str(e)}")
                    self.log_writing(f"Connection failed, retrying {retry_count}/{max_retries}. Exception: {str(e)}", "ERROR")

                    if retry_count == max_retries:
                        print("Maximum retry reached")
                        self.log_writing("Maximum retry reached", "ERROR")

                        print(f"Connection to {self.mq_server_name} with port {self.activemq_port} Failed After 3 retries")
                        self.log_writing(f"Connection to {self.mq_server_name} with port {self.activemq_port} "
                                        f"Failed After 3 retries", "INFO")
                        print("Script terminating after max retry attempts!")
                        self.log_writing("Script terminating after max retry attempts!", "INFO")
                        # self.send_failure_activemq_status(queueDetails='', status='ACTIVEMQ_FAILED')
                        self.log_writing(f"{self.mq_server_name}_FAILED", "INFO")
                        self.log_writing("Script terminating!!!!", "INFO")
                        print("Script terminating !!!!")
                        #sys.exit(0)
                        os._exit(0)

                    time.sleep(2)


        except NotConnectedException as e:  # amazon mq connection failed exception

            print(f"Connection to {self.mq_server_name} with port {self.activemq_port} Failed , So initiating Retries")
            self.log_writing(f"Connection to {self.mq_server_name} with port {self.activemq_port} Failed , "
                             f"So initiating Retries !!", "INFO")
            retry_count += 1
            print(f"Retry {retry_count}/{max_retries} failed: {str(e)}")
            self.log_writing(f"Connection failed, retrying {retry_count}/{max_retries}. Exception: {str(e)}", "ERROR")

            sleep_time = random.randint(5, 15)
            self.log_writing(f"Sleeping for {sleep_time} secs...", "INFO")
            time.sleep(sleep_time)

            if retry_count == max_retries:
                print("Maximum retry reached")
                self.log_writing("Maximum retry reached", "ERROR")

                print(f"Connection to {self.mq_server_name} with port {self.activemq_port} Failed After 3 retries")
                self.log_writing(f"Connection to {self.mq_server_name} with port {self.activemq_port} "
                                 f"Failed After 3 retries", "INFO")
                print("Script terminating after max retry attempts!")
                self.log_writing("Script terminating after max retry attempts!", "INFO")
                # self.send_failure_activemq_status(queueDetails='', status='ACTIVEMQ_FAILED')
                self.log_writing(f"{self.mq_server_name}_FAILED", "INFO")
                self.log_writing("Script terminating!!!!", "INFO")
                print("Script terminating !!!!")
                #sys.exit(0)
                os._exit(0)

            time.sleep(2)

        except ConnectFailedException as e:  # active mq connection failed exception
            print(f"Connection to {self.mq_server_name} with port {self.activemq_port} Failed, So initiating Retries")
            self.log_writing(
                f"Connection to {self.mq_server_name} with port {self.activemq_port} Failed, So initiating Retries !!",
                "INFO")
            retry_count += 1
            print(f"Retry {retry_count}/{max_retries} failed: {str(e)}")
            self.log_writing(f"Connection failed, retrying {retry_count}/{max_retries}. Exception: {str(e)}", "ERROR")

            sleep_time = random.randint(5, 15)
            self.log_writing(f"Sleeping for {sleep_time} secs...", "INFO")
            time.sleep(sleep_time)

            if retry_count == max_retries:
                print("Maximum retry reached")
                self.log_writing("Maximum retry reached", "ERROR")

                print(f"Connection to {self.mq_server_name} with port {self.activemq_port} Failed After 3 retries")
                self.log_writing( f"Connection to {self.mq_server_name} with port {self.activemq_port} "
                                  f"Failed After 3 retries", "INFO")

                print("Script terminating after max retry attempts!")
                self.log_writing("Script terminating after max retry attempts!", "INFO")

                self.log_writing("Script terminating........", "INFO")
                print("Script terminating........")
                os._exit(0)

            time.sleep(2)

    def push_json_to_statuesqueue_websiteblock(self, queueDetails):

        try:

            self.log_writing("status  queue website method called", "INFO")
            local_hostname = socket.gethostname()
            local_ip = socket.gethostbyname(local_hostname)
            self.log_writing("Calling bot base status queue website blocked messages", "INFO")
            csp_id = int(queueDetails['csp_id'])
            if csp_id == 1:
                processed_ip = botBase.retrieving_aws_instance_metadata(self)
            else:
                processed_ip = self.retrieving_localinfra_ip(self)

            json_data = {
                "container_ip": botBase.containerIpPatternMatch(self, local_ip),
                "processed_ip": processed_ip,
                "ack_message_count": "",
                "bot_name": "",
                "bot_status": "WEBSITE_BLOCKED",
                "user_id": "",
                "job_id": queueDetails['job_id'],
                "is_always_on": queueDetails['is_always_on'],
                "max_replicas_per_vm": queueDetails.get('max_replicas_per_vm', ''),
                "bot_id": "",
                "csp_id": queueDetails['csp_id']
            }
            host = queueDetails['activemq_ip']
            print("JSON data .....", json_data)
            conn_push_sq_websiteblock = stomp.Connection([(host, self.activemq_port)])
            conn_push_sq_websiteblock.connect()
            queue_name = queueDetails['status_queue']
            time.sleep(3)
            conn_push_sq_websiteblock.send(body=json.dumps(json_data), destination=queue_name)
            self.log_writing("queue connection established on bot base on connect and push json "
                             "push_json_to_statuesqueue_websiteblock method" + queue_name, "INFO")
            conn_push_sq_websiteblock.disconnect()

            self.log_writing("queue connection disconnected on bot base on connect and push json "
                             "push_json_to_statuesqueue_websiteblock" + queue_name, "INFO")
            print("JSON data sent successfully.")
            sys.exit(0)

        except Exception as e:
            self.log_writing("To send status queue data website blocked Exception:" + e, "ERROR")

    def push_json_to_statuesqueue_ipblock(self, port, queueDetails, status, inputAftJsonfile):

        try:

            input_queue_name = queueDetails['input_queue']
            host = queueDetails['activemq_ip']
            k = len(inputAftJsonfile)
            self.log_writing(k, "INFO")
            self.log_writing("queue connection established on send message to input queue on bot base "
                             "to_statuesqueue_ipblock method :" + input_queue_name, "INFO")
            i = 0
            # for inputvalues in inputAftJsonfile:
            # inputvalues = json.dumps(inputvalues)
            conn_iq_sq_ipblock = stomp.Connection([(host, self.activemq_port)])
            conn_iq_sq_ipblock.connect()
            time.sleep(1)
            self.log_writing(i, "INFO")

            conn_iq_sq_ipblock.send(body=inputAftJsonfile, destination=input_queue_name)
            conn_iq_sq_ipblock.disconnect()
            self.log_writing("queue connection disconnected on bot base on connect and send input json values to "
                             "input queue :" + input_queue_name, "INFO")

            local_hostname = socket.gethostname()
            local_ip = socket.gethostbyname(local_hostname)
            csp_id = int(queueDetails['csp_id'])
            if csp_id == 1:
                processed_ip = botBase.retrieving_aws_instance_metadata(self)
            else:
                processed_ip = self.retrieving_localinfra_ip(self)

            json_data = {
                "container_ip": botBase.containerIpPatternMatch(self, local_ip),
                "processed_ip": processed_ip,
                "ack_message_count": "",
                "bot_name": "",
                "bot_status": "IP_BLOCKED",
                "user_id": "",
                "job_id": queueDetails['job_id'],
                "is_always_on": queueDetails['is_always_on'],
                "max_replicas_per_vm": queueDetails.get('max_replicas_per_vm', ''),
                "bot_id": "",
                "csp_id": queueDetails['csp_id']
            }

            print("JSON data .....", json_data)
            conn_sq_ipblock = stomp.Connection([(host, self.activemq_port)])

            conn_sq_ipblock.connect()
            time.sleep(3)
            queue_name = queueDetails['status_queue']
            self.log_writing("queue connection establishing and send message to status queue on bot base "
                             "to_statuesqueue_ipblock method :" + queue_name, "INFO")
            conn_sq_ipblock.send(body=json.dumps(json_data), destination=queue_name)
            self.log_writing(
                " queue connection established and send message to status queue on bot base to_statuesqueue_ipblock method :" + queue_name,
                "INFO")
            conn_sq_ipblock.disconnect()
            sys.exit(0)

        except Exception as e:
            self.log_writing(
                "Exception occured in queue connection disconnected on bot base on connect and send input json values to input queue :" + input_queue_name + "-" + e,
                "INFO")
            sys.exit(0)

    def instance_config_json_reader(self):

        """
        function to read the configuration Json file
        """

        try:
            path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'Configuration.json')
            config_json = json.loads(open(path).read())
            return config_json

        except Exception as e:
            if re.search('No\s*such\s*file\s*or\s*directory', str(e), re.I):
                print('Configuration file is missing')
            else:
                print('Configuration file is missing::' + str(e))

    def retrieving_aws_instance_metadata(self):

        ec2_id = "Exception"

        try:

            ec2_metadata_url = "http://169.254.169.254/latest/meta-data/instance-id"
            response = requests.get(ec2_metadata_url)
            if response.status_code == 200:
                ec2_id = response.text

        except requests.exceptions.RequestException as request_exception:
            print("While Retrieving AWS Instance Metadata, an error occurred: " + str(request_exception))

        return ec2_id

    def retrieving_localinfra_ip(self):

        public_ip = None

        try:

            system_info = platform.uname()
            if system_info.system == 'Windows':
                process = subprocess.Popen(["curl", "ifconfig.me"], stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                           shell=True)
            else:
                process = subprocess.Popen(["/bin/bash", "-c", "curl ifconfig.me"], stdout=subprocess.PIPE,
                                           stderr=subprocess.PIPE)
            stdout, stderr = process.communicate()

            if process.returncode == 0:
                public_ip = stdout.decode("utf-8").strip()
                print("Localinfra server public ip is: " + public_ip)
            else:
                print("Failed to get Localinfra server public IP. Exit code:" + process.returncode)

        except Exception as e:
            print("Get Localinfra server public ip failed:" + e)

        return public_ip

    def containerIpPatternMatch(self, local_ip):

        ip_address_pattern = r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}'

        try:

            match = re.search(ip_address_pattern, local_ip)
            if match:
                ip_address = match.group()

                # logging.info("To get docker container IP Address: " + ip_address)
            else:
                logging.info("No container IP address found in the input.")

        except Exception as e:
            logging.error("No IP address found in the input." + e)

        return ip_address

    ###############

    def config_reader(self, config_file):
        """
        Function for configuration file reading
        """
        try:

            config_json_data = open(config_file)
            config_json = json.load(config_json_data)
            config_json_data.close()
            return config_json

        except Exception as exc:
            print("Error in config_reader::", str(exc))
            self.log_writing("Error in config_reader::" + str(exc), "ERROR")

            return False
            sys.exit(0)

    def get_processed_ip_(self):

        ip_flag = False

        try:

            hostname = socket.gethostname()
            IPAddr = socket.gethostbyname(hostname)
            ip_flag = True
            return IPAddr

        except Exception as e:
            self.log_writing(f'Unable to get public IP from -gethostname :::{e}', "INFO")
            ip_flag = False

        if ip_flag == False:

            try:

                stdout = sys.stdout
                sys.stdout = io.StringIO()
                public_ip_value = ''
                # call module that calls print()
                import publicip
                publicip.get()
                # get output and restore sys.stdout
                public_ip_value = sys.stdout.getvalue()
                sys.stdout = stdout
                if public_ip_value == '':
                    process_ip = ''

                    try:
                        process_ip = get('https://api.ipify.org').text
                        public_ip_value = process_ip
                    # print('public_ip_value')
                    except Exception as e:
                        # self.log_writing('Unable to get public IP from -https://api.ipify.org :::', "INFO")
                        print(f'No public_ip_value{e}')
                        return ""

                public_ip_value = public_ip_value.replace('\n', '')
                return public_ip_value

            except Exception as e:
                # self.log_writing('Unable to get public IP from -publicip module :::', "INFO")
                return ""

    def get_processed_ip_old(self):

        private_ip = ''
        publicip = ''

        try:

            hostname = socket.gethostname()
            IPAddr = socket.gethostbyname(hostname)
            private_ip = IPAddr
            print('private_ip::', private_ip)

            publicip = IP.get()
            print("publicip::", publicip)

        except Exception as e:
            # self.log_writing('Unable to get public IP from -hostname :::', "INFO")
            print(f'Unable to get public IP{e}')

        ip = private_ip + "_" + publicip
        # print('get_processed_ip----------',ip)
        return ip
    

    def get_processed_ip(self):

        private_ip = ''
        publicip = ''

        try:

            hostname = socket.gethostname()
            IPAddr = socket.gethostbyname(hostname)
            private_ip = IPAddr
            print('private_ip::', private_ip)

            # publicip = IP.get()
            # print("publicip::", publicip)

            try:
                publicip = requests.get('https://api.ipify.org').text
                #public_ip_value = process_ip
                # print('public_ip_value')
            except:
                # self.log_writing('Unable to get public IP from -https://api.ipify.org :::', "INFO")
                publicip = ""
                print('No public_ip_value')

        except Exception as e:
            # self.log_writing('Unable to get public IP from -hostname :::', "INFO")
            print(f'Unable to get public IP{e}')

        ip = private_ip + "_" + publicip
        # print('get_processed_ip----------',ip)
        return ip


    def output_writer_error(self, error_msg, error_code, bot_start_time, input_dict, PID, inputJsonfile,
                            bot_manager_url, messageid, conn):

        self.log_writing('Calling output_writer_error::', "INFO")
        output_format = json.load(open('output.json'))

        try:

            result = {"Output": {}}
            mainDict_n = {'ref_id': '', 'Processed_IP': '', 'bot_start_time': '', 'bot_end_time': '', "Input": {},
                          "error": {}, "Result": {}}
            mainDict_n['ref_id'] = input_dict['ref_id']
            mainDict_n['Processed_IP'] = self.get_processed_ip()
            mainDict_n['bot_start_time'] = bot_start_time

            error = {}
            error['error_message'] = error_msg
            error['error_code'] = error_code
            mainDict_n["error"] = error

            mainDict_n["Input"] = input_dict

            result = {}
            mainDict_n["Result"] = result

            output_list_test = []
            Output = {}
            output_list = []

            mainDict_n["Result"]["Output"] = output_list_test

            bot_end_time = re.sub('\.[^<]*?$', '', str(datetime.datetime.now()))
            mainDict_n['bot_end_time'] = bot_end_time
            mainDict_n = json.dumps(mainDict_n, indent=4)
            queueDetails = botBase.readQueueInfo(self)
            port = int(queueDetails['activemq_port'])

            # self.connect_and_push_messages(queueDetails['activemq_ip'], queueDetails['output_queue'],mainDict_n)
            # self.connect_and_push_messages(queueDetails['activemq_ip'], queueDetails['output_queue'],output_format)
            # self.acknowledgement(queueDetails['activemq_ip'],messageid[0], conn)

            is_push_successful = self.connect_and_push_messages(queueDetails['activemq_ip'],
                                                                queueDetails['output_queue'], mainDict_n)

            if is_push_successful:
                #self.acknowledgement(queueDetails['activemq_ip'], messageid[0], conn)
                self.acknowledgement(queueDetails['activemq_ip'], messageid, conn) #modified in 11.11.2025 by Gowri
                self.log_writing(f"Connect_and_push_message status {is_push_successful}", "INFO")
            else:
                self.log_writing("Message not pushed to queue, skipping acknowledgement.", "WARNING")

            self.log_writing(f"COMPLETED REF_ID::{input_dict['ref_id']} pid::{PID}", "INFO")

            # open(output_file_name, 'wb').write(mainDict_n.encode('utf-8'))

        except Exception as h:
            self.log_writing('Exception in output_writer_error::' + str(h), "INFO")

    def copy_inputJsonKeyValues_to_outputjson(self, input_dict, output_list, b_start_time, bot_end_time):

        """
        Merges input_dict into each dictionary in output_list.

        Args:
            input_dict (dict): Data to merge into each output item.
            output_list (list of dict): List of output dictionaries.
            b_start_time (str): The bot's start time.
            bot_end_time (str): The bot's end time.

        Returns:
            list of dict: Merged list with input_dict added to each output item.
        """

        try:

            self.log_writing("Starting merge of input_dict with each output item", "INFO")
            input_output_merged = []
            for val in output_list:
                merged_dict = {**val, **input_dict, 'bot_start_time': b_start_time, 'bot_end_time': bot_end_time}
                input_output_merged.append(merged_dict)
            self.log_writing("Successfully merged input_dict with output items", "INFO")
            return input_output_merged

        except Exception as exc:
            self.log_writing("Error in copy_inputJsonKeyValues_to_outputjson::" + str(exc), "ERROR")
            return []

    def generate_output(self, output, filename, input_dict, job_status, inputJsonfile, bot_manager_url, PID,
                        b_start_time, messageid, conn):

        try:

            output_format = json.load(open('output.json'))
            bot_end_time = re.sub('\.[^<]*?$', '', str(datetime.datetime.now()))

            if job_status == 'IN_PROGRESS':

                output_list = []
                output_format['ref_id'] = input_dict['ref_id']
                output_format['Processed_IP'] = self.get_processed_ip()
                output_format['bot_start_time'] = b_start_time
                output_format['bot_end_time'] = bot_end_time
                output_format['Input'] = input_dict
                output_format['Result']['Output'] = output_list
                outputJsonfile = 'Output_' + "0" + "_" + input_dict['ref_id'] + ".json"
                output_format = json.dumps(output_format, indent=4)
                self.log_writing("IN_PROGRESS::", "INFO")

            elif job_status == 'COMPLETED':
                # Merge input_dict with each output item, including bot start/end times
                input_output_merged = self.copy_inputJsonKeyValues_to_outputjson(input_dict, output, b_start_time,
                                                                                 bot_end_time)

                output_format['ref_id'] = input_dict['ref_id']
                output_format['Processed_IP'] = self.get_processed_ip()
                output_format['bot_start_time'] = b_start_time
                output_format['bot_end_time'] = bot_end_time
                output_format['Input'] = input_dict
                output_format['Result']['Output'] = input_output_merged

                #print("Final output::::::::::", output_format)
                print("============Final output generated in botbase===========")
                outputJsonfile = 'Output_' + str(len(output)) + "_" + input_dict['ref_id'] + ".json"

                output_format = json.dumps(output_format, indent=4)

                self.log_writing(f"COMPLETED REF_ID::{input_dict['ref_id']} pid::{PID}", "INFO")

            queueDetails = self.readQueueInfo()
            port = int(queueDetails['activemq_port'])

            # self.connect_and_push_messages(queueDetails['activemq_ip'], queueDetails['output_queue'],output_format)
            # self.acknowledgement(queueDetails['activemq_ip'],messageid[0], conn)

            is_push_successful = self.connect_and_push_messages(queueDetails['activemq_ip'],
                                                                queueDetails['output_queue'], output_format)

            if is_push_successful:

                self.log_writing(f"Connect_and_push_message status {is_push_successful}", "INFO")
                #self.acknowledgement(queueDetails['activemq_ip'], messageid[0], conn)
                self.acknowledgement(queueDetails['activemq_ip'], messageid, conn)

            else:
                self.log_writing("Message not pushed to queue, skipping acknowledgement.", "WARNING")

        except Exception as h:
            self.log_writing('Exception in generate_output::' + str(h), "INFO")

    def validate_input_json(self, inputjson_file):

        try:

            validate_flag = False
            ref_id_flag = True

            config = json.loads(inputjson_file)
            if config == False:
                print('Input JSON file unavailable')
                self.log_writing("Input JSON file unavailable", "ERROR")
                sys.exit(0)
            if 'bot_input' in config:
                print('bot_input key available!!!')
            else:
                validate_flag = True
                print('bot_input key Not available')
                print('Input Json validation Failed !!!')

                with open("Error_Log.txt", "a") as f:
                    f.write("bot_input JSON key missing/differs" + '\t' + str(datetime.datetime.now()) + '\n')
                self.log_writing("bot_input JSON key missing/differs", "ERROR")
                self.log_writing("Input Json validation Failed !!!", "ERROR")
            if 'ref_id' in config['bot_input'][0].keys():
                print("ref_id key available!!!")

            else:
                validate_flag = True
                ref_id_flag = False
                print("ref_id is not available!!!")
                with open("Error_Log.txt", "a") as f:
                    f.write("ref_id key is Unavailable!!!" + '\t' + str(datetime.datetime.now()) + '\n')
                self.log_writing("ref_id key is Unavailable!!!", "ERROR")

            if ref_id_flag == True:
                ref_id_value = config['bot_input'][0]['ref_id']
                if ref_id_value != '':
                    print("ref_id_value is available!!!")
                else:
                    validate_flag = True
                    print("ref_id_value is empty!!!")
                    self.log_writing("ref_id_value is empty!!!", "ERROR")
                    with open("Error_Log.txt", "a") as f:
                        f.write("ref_id_value is empty!!!" + '\t' + str(datetime.datetime.now()) + '\n')
            if validate_flag == True:
                print("Input Json validation Failed")
                self.log_writing("Input Json validation Failed !!!", "ERROR")

                sys.exit(0)
            elif validate_flag == False:
                print("Input Json validation Passed !!!")
                self.log_writing("Input Json validation Passed", "INFO")

                return (True, config, config['bot_input'][0])

        except Exception as exc:
            self.log_writing("Error in validate_input_json::" + str(exc), "ERROR")
            sys.exit(0)

    def send_msg_initiated(self, conn, queueDetails, inputs_dict, PROCESSED_IP):

        '''sends the message if the processing queue key is present in queueinfo.json ; otherwise, it skips queue creation'''

        try:

            # Check if 'ProcessingQueue' key exists in queueDetails
            if "ProcessingQueue" in queueDetails:
                queue_name = queueDetails["ProcessingQueue"]
                data = {'processed_ip': PROCESSED_IP}
                inputs_dict.update(data)
                output_format = json.dumps(inputs_dict, indent=None)

                print('queue_name', queue_name)
                print('inputs_dict', inputs_dict)
                print('output_format', output_format)

                conn.connect()
                self.log_writing(f"Sending INITIATED message to the queue::{queue_name} --- {output_format}", "INFO")
                conn.send(body=output_format, destination=queue_name)
            else:
                self.log_writing("ProcessingQueue key not found in queueDetails. No message sent.", "INFO")

        except Exception as h:
            self.log_writing('Exception in send_msg_initiated::' + str(h), "INFO")

    def send_failure_activemq_status(self, queueDetails, status):

        try:

            queueDetails = botBase.readQueueInfo(self)

            self.log_writing("send_failure_activemq_status calling::", "INFO")
            local_hostname = socket.gethostname()
            local_ip = socket.gethostbyname(local_hostname)
            self.log_writing("Calling bot base -- send_failure_activemq_status:: ", "INFO")
            csp_id = int(queueDetails['csp_id'])
            if csp_id == 1:
                processed_ip = botBase.retrieving_aws_instance_metadata(self)
            else:
                processed_ip = botBase.retrieving_localinfra_ip(self)
            json_data = {
                "container_ip": botBase.containerIpPatternMatch(self, local_ip),
                "processed_ip": processed_ip,
                "ack_message_count": "",
                "bot_name": "",
                "bot_status": f"{self.mq_server_name}_FAILED",
                "user_id": "",
                "job_id": queueDetails['job_id'],
                "is_always_on": queueDetails['is_always_on'],
                "max_replicas_per_vm": queueDetails.get('max_replicas_per_vm', ''),
                "bot_id": "",
                "csp_id": queueDetails['csp_id']
            }
            host = queueDetails['activemq_ip']
            self.log_writing("JSON data ....." + str(json_data), "INFO")
            # print('self.activemq_port',self.activemq_port)
            conn_send_failure_activemq_status = stomp.Connection([(host, self.activemq_port)])

            conn_send_failure_activemq_status.connect()
            queue_name = queueDetails['status_queue']
            time.sleep(1)
            conn_send_failure_activemq_status.send(body=json.dumps(json_data), destination=queue_name)
            logging.info(
                " queue connection established on bot base on connect and push message to status queue method :" + queue_name)
            conn_send_failure_activemq_status.disconnect()
            logging.info(
                "queue connection disconnected on bot base on connect and push json to status queue method :" + queue_name)
            print("JSON data sent successfully.")

        except Exception as e:
            # logging.error("Exception in send_failure_activemq_status::", e)
            self.log_writing("Exception in send_failure_activemq_status::" + str(e), "ERROR")

    def upload_file_to_samba(self, server_ip, username, password, share_folder, file_to_upload, bot_output_root_folder):
        """
        Uploads a file to a Samba server in a folder named after the batch_id.

        Args:
            server_ip (str): The Samba server IP address.
            username (str): The Samba username.
            password (str): The Samba password.
            share_folder (str): The shared folder on the Samba server.
            file_to_upload (str): The name of the file to be uploaded.
            bot_output_root_folder (str): The local folder where the file is stored.

        Returns:
            tuple: (remote_file_path, "") on success, (False, "") on failure.
        """

        try:
            # ✅ Construct absolute path to the file to upload
            local_file_path = os.path.abspath(file_to_upload)
            self.log_writing("🔍 Checking local file path: " + local_file_path, "INFO")

            if not os.path.exists(local_file_path):
                raise FileNotFoundError(f"❌ Local file not found: {local_file_path}")

            self.log_writing(f"✅ File '{local_file_path}' exists. Proceeding with upload.", "INFO")

            # ✅ Format remote paths
            remote_dir_path = f"//{server_ip}/{share_folder}/{bot_output_root_folder}".replace("\\", "/")
            remote_file_path = f"{remote_dir_path}/{os.path.basename(file_to_upload)}".replace("\\", "/")

            self.log_writing(f"🟢 Preparing to upload: '{local_file_path}' → '{remote_file_path}'", "INFO")

            # ✅ Register SMB session
            register_session(server_ip, username=username, password=password)

            # ✅ Ensure the remote directory exists
            try:
                smbclient.listdir(remote_dir_path)  # Check if directory exists
            except SMBException:
                self.log_writing(f"📁 Directory '{remote_dir_path}' does not exist. Creating it...", "INFO")
                base_smb_path = f"//{server_ip}/{share_folder}"
                self.create_smb_dirs(base_smb_path, remote_dir_path)

            # ✅ Upload the file
            with open(local_file_path, "rb") as local_file:
                with open_file(remote_file_path, mode="wb") as remote_file:
                    remote_file.write(local_file.read())

            self.log_writing(f"✅ File uploaded successfully: '{local_file_path}' → '{remote_file_path}'", "INFO")
            samba_signed_url = "file:" + remote_file_path
            return remote_file_path, samba_signed_url

        except AccessDenied as e:
            self.log_writing(f"🚫 Access Denied while uploading: {str(e)}", "ERROR")

        except SMBException as e:
            self.log_writing(f"❌ SMB Error during upload: {str(e)}", "ERROR")

        except FileNotFoundError as e:
            self.log_writing(f"❌ Local file not found: {str(e)}", "ERROR")

        except OSError as e:
            self.log_writing(f"📛 OS Error: {str(e)}", "ERROR")

        except Exception as e:
            self.log_writing(f"⚠️ Unexpected error during SMB upload: {str(e)}", "ERROR")

        return False, ""

    def create_smb_dirs(self, base_path, target_path):
        """
        Create missing directories recursively from 'offline-files' onward.

        :param base_path: The root SMB share (e.g., '//10.101.7.122/Private')
        :param target_path: The full path to the directory to be created
        """
        try:
            relative_path = target_path.replace(base_path, "").strip("/")
            sub_dirs = relative_path.split("/")
            current_path = base_path

            for sub_dir in sub_dirs:
                current_path += f"/{sub_dir}"

                try:
                    smbclient.listdir(current_path)  # Check if directory exists
                except SMBException:
                    try:
                        self.log_writing(f"📁 Creating directory: {current_path}", "INFO")
                        smbclient.mkdir(current_path)
                    except SMBException as smb_err:
                        self.log_writing(f"❌ SMB Error while creating directory '{current_path}': {smb_err}", "ERROR")
                        raise
                    except PermissionError as perm_err:
                        self.log_writing(f"🚫 Permission denied for creating '{current_path}': {perm_err}", "ERROR")
                        raise
                    except Exception as ex:
                        self.log_writing(f"⚠️ Unexpected error creating '{current_path}': {ex}", "ERROR")
                        raise
        except Exception as outer_ex:
            self.log_writing(f"❌ Failed during SMB directory creation process: {outer_ex}", "ERROR")
            raise

    def download_file_from_smb(self, server_ip, username, password, share_folder, local_save_path, samba_file_path):
        """
        Downloads a file from an SMB share.

        :param server_ip: SMB server IP or hostname
        :param username: SMB login username
        :param password: SMB login password
        :param share_folder: The shared folder name on the SMB server
        :param local_save_path: The local path where the file should be saved
        :param samba_file_path: The path to the file on the SMB share
        """
        success_flag = False

        try:
            # Register the SMB session
            register_session(server_ip, username=username, password=password)
            self.log_writing(f"📡 SMB session registered with {server_ip}", "INFO")

            # Build the remote path
            remote_file_path = f"\\\\{server_ip}\\{share_folder}\\{samba_file_path}".replace("/", "\\")
            self.log_writing("📂 Remote SMB file path: " + remote_file_path, "INFO")

            # Attempt to open and download the file
            with open_file(remote_file_path, mode="rb") as remote_file:
                with open(local_save_path, "wb") as local_file:
                    local_file.write(remote_file.read())

            self.log_writing(f"✅ File downloaded from '{remote_file_path}' to '{local_save_path}'", "INFO")
            success_flag = True

        except AccessDenied as e:
            self.log_writing(f"❌ Access Denied to SMB resource: {str(e)}", "ERROR")

        except SMBException as e:
            self.log_writing(f"❌ General SMB error occurred: {str(e)}", "ERROR")

        except FileNotFoundError as e:
            self.log_writing(f"❌ Local file path error: {str(e)}", "ERROR")

        except Exception as e:
            self.log_writing(f"⚠️ Unexpected exception in Samba download: {str(e)}", "ERROR")

        return success_flag, local_save_path if success_flag else (False, None)

    def role_based_s3_upload_file(self, bucket_name, region, bot_output_root_folder, file_to_upload, expiration):
        """
        Uploads files to S3 using IAM role or default AWS credentials.

        Returns:
            tuple: (uploaded_file_path, signed_url) or ("", "") on failure.
        """
        self.log_writing("📦 Calling role_based_s3_upload_file...", "INFO")

        signed_url = ""
        connected = False
        count = 1
        path = ""

        # ✅ Initialize S3 resource with proper error handling
        try:
            s3 = boto3.resource("s3", region_name=region)
        except (NoCredentialsError, PartialCredentialsError):
            self.log_writing("❌ Missing or invalid AWS credentials for role-based upload.", "ERROR")
            return "", ""
        except BotoCoreError as e:
            self.log_writing(f"⚠️ BotoCoreError while creating S3 resource: {str(e)}", "ERROR")
            return "", ""
        except Exception as e:
            self.log_writing(f"⚠️ Unexpected error creating S3 resource: {str(e)}", "ERROR")
            return "", ""

        while not connected:
            try:
                bucket = s3.Bucket(bucket_name)
                path = f"{bot_output_root_folder}/{os.path.basename(file_to_upload)}"
                self.log_writing(f"📤 Uploading '{file_to_upload}' → S3 bucket '{bucket_name}' at '{path}'", "INFO")

                bucket.upload_file(file_to_upload, path)
                connected = True

                # ✅ Create S3 client with error handling
                try:
                    s3_client = boto3.client(
                        's3',
                        region_name=region,
                        config=boto3.session.Config(signature_version='s3v4')
                    )
                except (NoCredentialsError, PartialCredentialsError):
                    self.log_writing("❌ Missing or invalid AWS credentials for S3 client.", "ERROR")
                    return path, ""
                except BotoCoreError as e:
                    self.log_writing(f"⚠️ BotoCoreError while creating S3 client: {str(e)}", "ERROR")
                    return path, ""
                except Exception as e:
                    self.log_writing(f"⚠️ Unexpected error creating S3 client: {str(e)}", "ERROR")
                    return path, ""

                # ✅ Generate signed URL
                signed_url = s3_client.generate_presigned_url(
                    'get_object',
                    Params={'Bucket': bucket_name, 'Key': path},
                    ExpiresIn=expiration
                )
                self.log_writing(f"🔗 Signed URL generated: {signed_url}", "INFO")

            except FileNotFoundError:
                self.log_writing(f"❌ Local file not found: {file_to_upload}", "ERROR")
                break
            except EndpointConnectionError as conn_err:
                self.log_writing(f"❌ Could not connect to S3 endpoint: {conn_err}", "ERROR")
                break
            except ClientError as client_err:
                self.log_writing(f"❌ S3 Client error occurred: {client_err}", "ERROR")
                break
            except Exception as e:
                self.log_writing(f"⚠️ General exception during S3 upload attempt {count}: {str(e)}", "ERROR")
                count += 1
                if count <= 3:
                    self.log_writing("🔁 Retrying upload...", "INFO")
                    continue
                else:
                    self.log_writing(f"❌ Max retries exceeded in role_based_s3_upload_file: {str(e)}", "ERROR")
                    break

        if connected:
            self.log_writing("✅ File uploaded successfully to S3", "INFO")
        else:
            self.log_writing("❌ File upload to S3 failed", "ERROR")

        return (path if connected else ""), (signed_url if connected else "")

    def key_based_s3_upload_file(self, access_key, secret_key, bucket_name, region, bot_output_root_folder,
                                 file_to_upload, expiration):
        """
        Uploads files to Amazon S3 using explicit AWS credentials.

        Returns:
            tuple: (uploaded_file_path, signed_url) or ("", "") on failure.
        """
        self.log_writing("🔐 Calling key_based_s3_upload_file...", "INFO")

        connected = False
        count = 1
        path = ""
        signed_url = ""

        try:
            s3 = boto3.resource(
                "s3",
                aws_access_key_id=access_key,
                aws_secret_access_key=secret_key,
                region_name=region
            )
        except (NoCredentialsError, PartialCredentialsError):
            self.log_writing("❌ Invalid or missing AWS credentials for S3 resource.", "ERROR")
            return "", ""
        except BotoCoreError as e:
            self.log_writing(f"⚠️ BotoCoreError while creating S3 resource: {str(e)}", "ERROR")
            return "", ""
        except Exception as e:
            self.log_writing(f"⚠️ Unexpected error creating S3 resource: {str(e)}", "ERROR")
            return "", ""

        while not connected:
            try:
                bucket = s3.Bucket(bucket_name)
                path = f"{bot_output_root_folder}/{os.path.basename(file_to_upload)}"

                self.log_writing(f"📤 Uploading '{file_to_upload}' → S3 bucket '{bucket_name}' at '{path}'", "INFO")
                bucket.upload_file(file_to_upload, path)
                connected = True

                try:
                    s3_client = boto3.client(
                        's3',
                        aws_access_key_id=access_key,
                        aws_secret_access_key=secret_key,
                        region_name=region,
                        config=boto3.session.Config(signature_version='s3v4')
                    )
                except (NoCredentialsError, PartialCredentialsError):
                    self.log_writing("❌ Invalid or missing AWS credentials for S3 client.", "ERROR")
                    return path, ""
                except BotoCoreError as e:
                    self.log_writing(f"⚠️ BotoCoreError while creating S3 client: {str(e)}", "ERROR")
                    return path, ""
                except Exception as e:
                    self.log_writing(f"⚠️ Unexpected error creating S3 client: {str(e)}", "ERROR")
                    return path, ""

                signed_url = s3_client.generate_presigned_url(
                    'get_object',
                    Params={'Bucket': bucket_name, 'Key': path},
                    ExpiresIn=expiration
                )
                self.log_writing(f"🔗 Signed URL generated: {signed_url}", "INFO")

            except FileNotFoundError:
                self.log_writing(f"❌ Local file not found: {file_to_upload}", "ERROR")
                break
            except EndpointConnectionError as conn_err:
                self.log_writing(f"❌ Could not connect to S3 endpoint: {conn_err}", "ERROR")
                break
            except ClientError as client_err:
                self.log_writing(f"❌ S3 Client error: {client_err}", "ERROR")
                break
            except Exception as e:
                self.log_writing(f"⚠️ General exception during upload attempt {count}: {str(e)}", "ERROR")
                count += 1
                if count <= 3:
                    self.log_writing("🔁 Retrying upload...", "INFO")
                    continue
                else:
                    self.log_writing(f"❌ Max retries exceeded. Exception: {str(e)}", "ERROR")
                    break

        if connected:
            self.log_writing("✅ File uploaded successfully to S3", "INFO")
        else:
            self.log_writing("❌ File upload to S3 failed", "ERROR")

        return (path if connected else ""), (signed_url if connected else "")

    def role_based_s3_download_file(self, bucket_name, region, s3_file_path, local_filename):
        """
        Downloads a file from S3 using IAM role or default credentials.
        If the file already exists locally, it is used.
        Returns True and path on success, otherwise False and empty string.
        """
        self.log_writing("📥 Calling role_based_s3_download_file...", "INFO")

        try:
            s3 = boto3.client("s3", region_name=region)
        except NoCredentialsError:
            self.log_writing("❌ Missing AWS credentials for role-based access.", "ERROR")
            return False, ""
        except PartialCredentialsError:
            self.log_writing("❌ Incomplete AWS credentials for role-based access.", "ERROR")
            return False, ""
        except BotoCoreError as e:
            self.log_writing(f"⚠️ BotoCoreError while creating S3 client: {str(e)}", "ERROR")
            return False, ""
        except Exception as e:
            self.log_writing(f"⚠️ Unexpected error creating S3 client: {str(e)}", "ERROR")
            return False, ""

        try:
            if os.path.exists(local_filename):
                self.log_writing(f"✅ File already exists locally: {local_filename}", "INFO")
                return True, local_filename

            self.log_writing(f"📥 Downloading '{s3_file_path}' from bucket '{bucket_name}'", "INFO")
            s3.download_file(bucket_name, s3_file_path, local_filename)
            self.log_writing(f"✅ File downloaded to '{local_filename}'", "INFO")
            return True, local_filename

        except FileNotFoundError:
            self.log_writing(f"❌ Local path not found to save file: {local_filename}", "ERROR")
        except EndpointConnectionError as conn_err:
            self.log_writing(f"❌ Could not connect to S3 endpoint: {conn_err}", "ERROR")
        except ClientError as client_err:
            self.log_writing(f"❌ Client error during download: {client_err}", "ERROR")
        except Exception as e:
            self.log_writing(f"⚠️ Unexpected error in role_based_s3_download_file: {str(e)}", "ERROR")

        return False, ""

    def key_based_s3_download_file(self, access_key, secret_key, bucket_name, s3_file_path, local_filename):
        """
        Downloads a file from S3 using explicit AWS credentials.
        If the file already exists locally, it is used.
        Returns True and path on success, otherwise False and empty string.
        """
        self.log_writing("🔑 Calling key_based_s3_download_file...", "INFO")

        try:
            s3 = boto3.client(
                's3',
                aws_access_key_id=access_key,
                aws_secret_access_key=secret_key
            )
        except NoCredentialsError:
            self.log_writing("❌ Missing AWS credentials.", "ERROR")
            return False, ""
        except PartialCredentialsError:
            self.log_writing("❌ Incomplete AWS credentials provided.", "ERROR")
            return False, ""
        except BotoCoreError as e:
            self.log_writing(f"⚠️ BotoCoreError while creating S3 client: {str(e)}", "ERROR")
            return False, ""
        except Exception as e:
            self.log_writing(f"⚠️ Unexpected error creating S3 client: {str(e)}", "ERROR")
            return False, ""

        try:
            if os.path.exists(local_filename):
                self.log_writing(f"✅ File already exists locally: {local_filename}", "INFO")
                return True, local_filename

            self.log_writing(f"📥 Downloading '{s3_file_path}' from bucket '{bucket_name}'", "INFO")
            s3.download_file(bucket_name, s3_file_path, local_filename)
            self.log_writing(f"✅ File downloaded to '{local_filename}'", "INFO")
            return True, local_filename

        except FileNotFoundError:
            self.log_writing(f"❌ Local path not found to save file: {local_filename}", "ERROR")
        except EndpointConnectionError as conn_err:
            self.log_writing(f"❌ Could not connect to S3 endpoint: {conn_err}", "ERROR")
        except ClientError as client_err:
            self.log_writing(f"❌ Client error during download: {client_err}", "ERROR")
        except Exception as e:
            self.log_writing(f"⚠️ Unexpected error in key_based_s3_download_file: {str(e)}", "ERROR")

        return False, ""
    

    def cleanup_memory(self):
        try:
            # Clear big objects
            for name, obj in list(locals().items()):
                if isinstance(obj, (dict, list, set, tuple, bytes, bytearray)):
                    try:
                        obj.clear()
                        print("Objects cleared")
                        self.log_writing("Objects cleared", "INFO")
                    except:
                        pass
            # Delete all local variables
            for name in list(locals().keys()):
                try:
                    del locals()[name]
                    self.log_writing("Deleted all local variables", "INFO")
                except:
                    pass
            gc.collect()

        except Exception as e :
            print(f"Error in cleanup_memory: {str(e)}")
            self.log_writing(f"Error in cleanup_memory: {str(e)}", "ERROR")
            

    def infinite_sleep(self):
        try: 
            self.log_writing("Unconditional sleep time", "INFO")
            print("Unconditional sleep time")
            while True:
                # unconditional 30 min sleep
                self.log_writing("Sleeping for 30 minutes...", "INFO")
                print("Sleeping for 30 minutes...")
                time.sleep(1800)  # 30 minutes 


        except Exception as e:
            self.log_writing(f"Error in infinite_sleep : {str(e)}", "INFO")
            print(f"Error in infinite_sleep : {str(e)}")

            